package com.example.core;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.BanList;
import org.bukkit.command.Command;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;

public final class CorePlugin extends JavaPlugin implements Listener, TabCompleter {

    private static final String FIRE_ID = "FIRE_MACE";
    private static final String WIND_ID = "WIND_MACE";
    private static final String ZEUS_ID = "ZEUS_MACE";
    private static final String JESTER_ID = "JESTER_MACE";
    private static final String WRATH_ID = "WRATH_MACE";
    private static final String LUCK_ID = "LUCK_MACE";
    private static final String WARDEN_ID = "WARDEN_MACE";
    private static final String VOID_ID = "VOID_MACE";
    private static final String VISION_ID = "VISION_MACE";
    private static final String DUNE_ID = "DUNE_MACE";

    private static final String ITEM_TRADER = "MACE_TRADER";
    private static final String ITEM_REVIVE = "REVIVE_BEACON";
    private static final String ITEM_REPAIR = "REPAIR_KIT";
    private static final String ITEM_ENERGY = "ENERGY_BOTTLE";

    private static final String FIREBALL_META = "core_fireball_projectile";
    private static final String REVIVE_MENU_TITLE = ChatColor.DARK_AQUA + "Revive Beacon";
    private static final String RECIPE_MENU_TITLE = ChatColor.GOLD + "Core Recipes";
    private static final String RECIPE_DETAIL_PREFIX = ChatColor.GOLD + "Recipe: ";
    private static final int MAX_ENERGY = 5;

    private final Random random = new Random();
    private final Map<UUID, Long> fireCooldown = new HashMap<>();
    private final Map<UUID, Long> windCooldown = new HashMap<>();
    private final Map<UUID, Long> fireAuraCooldown = new HashMap<>();
    private final Map<UUID, Long> zeusLightningCooldown = new HashMap<>();
    private final Map<UUID, Long> zeusLockCooldown = new HashMap<>();
    private final Map<UUID, Long> jesterDebuffCooldown = new HashMap<>();
    private final Map<UUID, Long> jesterCopyCooldown = new HashMap<>();
    private final Map<UUID, Long> wrathBloodhuntCooldown = new HashMap<>();
    private final Map<UUID, Long> wardenSlamCooldown = new HashMap<>();
    private final Map<UUID, Long> wardenDarknessCooldown = new HashMap<>();
    private final Map<UUID, Long> voidBlinkCooldown = new HashMap<>();
    private final Map<UUID, Long> voidPullCooldown = new HashMap<>();
    private final Map<UUID, Long> visionBlindCooldown = new HashMap<>();
    private final Map<UUID, Long> visionVoidCooldown = new HashMap<>();
    private final Map<UUID, Long> duneWaveCooldown = new HashMap<>();
    private final Map<UUID, Long> dunePitCooldown = new HashMap<>();
    private final Set<UUID> duneTrapped = new HashSet<>();
    private final Map<UUID, Integer> jesterHitCount = new HashMap<>();
    private final Map<UUID, Integer> jesterCopyHitsLeft = new HashMap<>();
    private final Map<UUID, String> jesterOriginalMace = new HashMap<>();
    private final Map<UUID, Map<Enchantment, Integer>> jesterCopiedEnchantments = new HashMap<>();
    private final Map<UUID, BossBar> wrathBars = new HashMap<>();

    private final Map<UUID, TestSession> activeTests = new HashMap<>();
    private final Map<UUID, InventorySnapshot> testSnapshots = new HashMap<>();
    private final Set<UUID> pendingTestRoundReset = new HashSet<>();

    private final Map<UUID, Set<UUID>> wrathMarkedPlayers = new HashMap<>();
    private final Map<UUID, Long> luckCoinCooldown = new HashMap<>();
    private final Map<UUID, Long> luckArmedUntil = new HashMap<>();
    private final Map<UUID, Integer> luckBackfireStreak = new HashMap<>();
    private final Map<UUID, Integer> luckShockwaveStreak = new HashMap<>();
    private final Map<UUID, BossBar> luckBars = new HashMap<>();
    private final Map<UUID, Long> frozenUntil = new HashMap<>();
    private final Map<UUID, Float> savedWalkSpeed = new HashMap<>();
    private static final int PHASE_NOT_STARTED = 0;
    private static final int PHASE_ONE = 1;
    private static final int PHASE_TWO = 2;

    private NamespacedKey maceIdKey;
    private NamespacedKey specialItemKey;

    private final Map<UUID, Map<Enchantment, Integer>> jesterOriginalEnchants = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maceIdKey = new NamespacedKey(this, "mace_id");
        specialItemKey = new NamespacedKey(this, "special_item_id");
        applyDefaultConfigValues();
        registerRecipes();
        if (getCommand("core") != null) {
            getCommand("core").setExecutor(this);
            getCommand("core").setTabCompleter(this);
        }
        Bukkit.getPluginManager().registerEvents(this, this);

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player online : Bukkit.getOnlinePlayers()) {
                updateHeldMaceCooldownBar(online);
            }
        }, 10L, 2L);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                refreshPassiveEffects(player);
                refreshDragonEggBuff(player);
                updateWrathBar(player);
                updateLuckBar(player);
                if (isPhaseOne()) {
                    enforcePhaseOneRestrictions(player);
                }
            }
        }, 1L, 10L);
        getLogger().info("Core enabled.");
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            cleanupFrozenPlayer(player);
            clearWrathEffects(player);
            removeLuckBar(player);
        }
        saveConfig();
    }

    private void applyDefaultConfigValues() {
        getConfig().addDefault("cooldowns.fire-seconds", 2.5);
        getConfig().addDefault("cooldowns.wind-seconds", 5.0);
        getConfig().addDefault("cooldowns.fire-aura-seconds", 18.0);
        getConfig().addDefault("cooldowns.zeus-lightning-seconds", 4.5);
        getConfig().addDefault("cooldowns.zeus-lock-seconds", 10.0);
        getConfig().addDefault("cooldowns.wrath-bloodhunt-seconds", 45.0);
        getConfig().addDefault("durations.wrath-bloodhunt-seconds", 10.0);
        getConfig().addDefault("cooldowns.luck-coin-seconds", 20.0);
        getConfig().addDefault("cooldowns.warden-slam-seconds", 10.0);
        getConfig().addDefault("cooldowns.warden-darkness-seconds", 16.0);
        getConfig().addDefault("cooldowns.void-blink-seconds", 8.0);
        getConfig().addDefault("cooldowns.void-pull-seconds", 14.0);
        getConfig().addDefault("cooldowns.vision-blind-seconds", 16.0);
        getConfig().addDefault("cooldowns.vision-void-seconds", 28.0);
        getConfig().addDefault("cooldowns.dune-wave-seconds", 10.0);
        getConfig().addDefault("cooldowns.dune-pit-seconds", 18.0);
        getConfig().addDefault("durations.luck-armed-seconds", 10.0);
        getConfig().addDefault("energy.max", MAX_ENERGY);
        getConfig().addDefault("game.started", false);
        getConfig().addDefault("game.phase", PHASE_NOT_STARTED);
        getConfig().options().copyDefaults(true);
        saveConfig();
    }


    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        TestSession session = activeTests.get(event.getPlayer().getUniqueId());
        if (session != null) {
            endTestMatch(session, session.opponent(event.getPlayer().getUniqueId()));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        storePlayerName(player);
        sanitizeInventory(player);
        if (isReviveBanned(player.getName())) {
            return;
        }

        Bukkit.getScheduler().runTask(this, () -> {
            sanitizeInventory(player);
            if (hasStarted() && !hasAnyCustomMace(player)) {
                if (getAssignedMaceId(player.getUniqueId()) == null) {
                    giveRandomMaceWithCircle(player);
                } else {
                    giveAssignedMaceInstant(player);
                }
            }
            if (isPhaseOne()) {
                enforcePhaseOneRestrictions(player);
            }
            refreshPassiveEffects(player);
            refreshMaceLore(player);
        });
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (activeTests.containsKey(player.getUniqueId())) {
            TestSession session = activeTests.get(player.getUniqueId());
            event.setRespawnLocation(session.spawnFor(player.getUniqueId()));
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (activeTests.containsKey(player.getUniqueId())) {
                    prepareTestRound(player, session.spawnFor(player.getUniqueId()));
                }
            }, 2L);
            return;
        }
        if (isReviveBanned(player.getName())) {
            return;
        }
        Bukkit.getScheduler().runTask(this, () -> {
            sanitizeInventory(player);
            if (hasStarted() && !hasAnyCustomMace(player)) {
                giveAssignedMaceInstant(player);
            }
            if (isPhaseOne()) {
                enforcePhaseOneRestrictions(player);
            }
            refreshPassiveEffects(player);
            refreshMaceLore(player);
        });
    }

    @EventHandler
    public void onHeld(PlayerItemHeldEvent event) {
        Bukkit.getScheduler().runTaskLater(this, () -> {
            refreshPassiveEffects(event.getPlayer());
            refreshMaceLore(event.getPlayer());
            refreshPlayerMaceModelStates(event.getPlayer());
            updateLuckBar(event.getPlayer());
        }, 1L);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (item != null && item.getType() == Material.ENDER_PEARL && hasStarted()) {
            event.setCancelled(true);
            player.sendActionBar(ChatColor.RED + "Ender pearls are disabled on this server.");
            return;
        }
        String specialId = getSpecialItemId(item);
        if (specialId != null) {
            switch (specialId) {
                case ITEM_TRADER -> useMaceTrader(player);
                case ITEM_REPAIR -> useRepairKit(player);
                case ITEM_ENERGY -> useEnergyBottle(player);
                case ITEM_REVIVE -> openReviveMenu(player);
            }
            return;
        }

        String maceId = getMaceId(item);
        if (maceId == null) return;

        if (isZeroEnergyDisabled(player)) {
            player.sendMessage(ChatColor.RED + "Your mace is dormant at 0 energy.");
            return;
        }

        boolean sneaking = player.isSneaking();
        switch (maceId) {
            case FIRE_ID -> {
                if (sneaking) {
                    useFireAura(player);
                } else {
                    useFireMace(player);
                }
            }
            case WIND_ID -> {
                event.setCancelled(true);
                useWindMace(player);
            }
            case ZEUS_ID -> {
                if (sneaking) {
                    useZeusLock(player);
                } else {
                    useZeusLightning(player);
                }
            }
            case WRATH_ID -> {
                useWrathBloodhunt(player);
            }
            case LUCK_ID -> {
                useLuckCoinToss(player);
            }
            case WARDEN_ID -> {
                if (sneaking) {
                    useWardenDarkness(player);
                } else {
                    useWardenSlam(player);
                }
            }
            case VOID_ID -> {
                if (sneaking) {
                    useVoidPull(player);
                } else {
                    useVoidBlink(player);
                }
            }
            case VISION_ID -> {
                if (sneaking) {
                    useVisionVoid(player);
                } else {
                    useVisionBlind(player);
                }
            }
            case DUNE_ID -> {
                if (sneaking) {
                    useDunePit(player);
                } else {
                    useDuneWave(player);
                }
            }
        }
    }





    @EventHandler
    public void onInventoryCloseForMaceModels(org.bukkit.event.inventory.InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            Bukkit.getScheduler().runTaskLater(this, () -> refreshPlayerMaceModelStates(player), 1L);
        }
    }


    @EventHandler
    public void onInventoryCreative(InventoryCreativeEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        if (blocksContainerStorage(event)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "Core items cannot be stored in containers, shulkers, bundles, or ender chests.");
            return;
        }

        if (isCustomPluginItem(event.getCursor()) || isCustomPluginItem(event.getCurrentItem())) {
            // Never sanitize or rewrite custom items in creative.
            return;
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event instanceof InventoryCreativeEvent) {
            return;
        }
        if (REVIVE_MENU_TITLE.equals(event.getView().getTitle())) {
            if (!(event.getWhoClicked() instanceof Player player)) return;
        Bukkit.getScheduler().runTaskLater(this, () -> refreshPlayerMaceModelStates(player), 1L);
        Bukkit.getScheduler().runTaskLater(this, () -> refreshPlayerMaceModelStates(player), 1L);
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || clicked.getType() == Material.AIR || !clicked.hasItemMeta()) return;
            if (clicked.getType() == Material.GRAY_STAINED_GLASS_PANE) return;
            if (!(clicked.getItemMeta() instanceof SkullMeta skullMeta)) return;

            OfflinePlayer target = skullMeta.getOwningPlayer();
            String targetName = target != null ? target.getName() : null;
            if (targetName == null || targetName.isBlank()) {
                player.sendMessage(ChatColor.RED + "That banned player entry is invalid.");
                player.closeInventory();
                return;
            }

            if (!isReviveBanned(targetName)) {
                player.sendMessage(ChatColor.RED + targetName + " is no longer waiting for a Revive Beacon.");
                player.closeInventory();
                return;
            }

            if (!consumeHeldSpecialItem(player, ITEM_REVIVE)) {
                player.closeInventory();
                return;
            }

            revivePlayerByName(targetName, player);
            player.closeInventory();
            return;
        }

        if (RECIPE_MENU_TITLE.equals(event.getView().getTitle())) {
            if (!(event.getWhoClicked() instanceof Player player)) return;
            int slot = event.getRawSlot();
            if (slot == 11) {
                openRecipeDetailMenu(player, "repair");
            } else if (slot == 13) {
                openRecipeDetailMenu(player, "trader");
            } else if (slot == 15) {
                openRecipeDetailMenu(player, "revive");
            }
            return;
        }

        if (event.getView().getTitle() != null && event.getView().getTitle().startsWith(RECIPE_DETAIL_PREFIX)) {
            if (event.getRawSlot() == 40 && event.getWhoClicked() instanceof Player player) {
                openRecipeMenu(player);
            }
            return;
        }

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (blocksContainerStorage(event)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "Core items cannot be stored in containers, shulkers, bundles, or ender chests.");
            return;
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Inventory top = event.getView().getTopInventory();
        if (top == null || !isStorageInventory(top.getType())) return;

        ItemStack oldCursor = event.getOldCursor();
        if (isCustomPluginItem(oldCursor)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "Core items cannot be stored in containers, shulkers, bundles, or ender chests.");
            return;
        }

        for (ItemStack item : event.getNewItems().values()) {
            if (isCustomPluginItem(item)) {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "Core items cannot be stored in containers, shulkers, bundles, or ender chests.");
                return;
            }
        }
    }



    private boolean blocksContainerStorage(InventoryCreativeEvent event) {
        Inventory clickedInventory = event.getClickedInventory();
        Inventory topInventory = event.getView().getTopInventory();
        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();

        if (isBundleBundleingCustom(cursor, current) || isBundleBundleingCustom(current, cursor)) {
            return true;
        }

        if (clickedInventory == null) return false;

        boolean clickedIsStorage = isStorageInventory(clickedInventory.getType());
        boolean topIsStorage = topInventory != null && isStorageInventory(topInventory.getType());

        if (clickedInventory.getType() != InventoryType.PLAYER) {
            return (isCustomPluginItem(cursor) || isCustomPluginItem(current)) && (clickedIsStorage || topIsStorage);
        }

        if (topInventory == null || topInventory.getType() == InventoryType.CRAFTING) return false;
        if (!topIsStorage) return false;

        return isCustomPluginItem(current) || isCustomPluginItem(cursor);
    }

    private boolean blocksContainerStorage(InventoryClickEvent event) {
        Inventory clickedInventory = event.getClickedInventory();
        Inventory topInventory = event.getView().getTopInventory();
        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();

        if (isBundleBundleingCustom(cursor, current) || isBundleBundleingCustom(current, cursor)) {
            return true;
        }

        if (clickedInventory == null) return false;

        boolean clickedIsStorage = isStorageInventory(clickedInventory.getType());
        boolean topIsStorage = topInventory != null && isStorageInventory(topInventory.getType());

        if (clickedInventory.getType() != InventoryType.PLAYER) {
            if (isCustomPluginItem(cursor) || isCustomPluginItem(current)) {
                return clickedIsStorage || topIsStorage;
            }
            if (event.getClick() == ClickType.NUMBER_KEY) {
                ItemStack hotbar = event.getWhoClicked().getInventory().getItem(event.getHotbarButton());
                return isCustomPluginItem(hotbar) && (clickedIsStorage || topIsStorage);
            }
            return false;
        }

        if (topInventory == null || topInventory.getType() == InventoryType.CRAFTING) return false;
        if (!topIsStorage) return false;

        if (event.isShiftClick() && isCustomPluginItem(current)) return true;
        if (isCustomPluginItem(cursor) || isCustomPluginItem(current)) return true;
        if (event.getClick() == ClickType.NUMBER_KEY) {
            ItemStack hotbar = event.getWhoClicked().getInventory().getItem(event.getHotbarButton());
            if (isCustomPluginItem(hotbar)) return true;
        }
        return false;
    }

    private boolean isBundleBundleingCustom(ItemStack first, ItemStack second) {
        return isBundle(first) && isCustomPluginItem(second);
    }

    private boolean isBundle(ItemStack item) {
        return item != null && item.getType() == Material.BUNDLE;
    }

    private boolean isStorageInventory(InventoryType type) {
        return type == InventoryType.CHEST
                || type == InventoryType.ENDER_CHEST
                || type == InventoryType.BARREL
                || type == InventoryType.SHULKER_BOX
                || type == InventoryType.HOPPER
                || type == InventoryType.DROPPER
                || type == InventoryType.DISPENSER;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        if (event.getInventory() == null || event.getInventory().getMatrix() == null) return;
        for (ItemStack item : event.getInventory().getMatrix()) {
            if (isCustomPluginItem(item)) {
                event.getInventory().setResult(null);
                return;
            }
        }
    }


    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEnchantItem(EnchantItemEvent event) {
        if (!isPhaseOne()) return;
        capEnchantMap(event.getEnchantsToAdd(), Enchantment.PROTECTION, 3);
        capEnchantMap(event.getEnchantsToAdd(), Enchantment.SHARPNESS, 4);
        capEnchantMap(event.getEnchantsToAdd(), Enchantment.DENSITY, 4);
        capEnchantMap(event.getEnchantsToAdd(), Enchantment.BREACH, 3);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        if (!isPhaseOne()) return;
        ItemStack result = event.getResult();
        if (result == null || result.getType() == Material.AIR) return;

        ItemStack capped = result.clone();
        capEnchant(capped, Enchantment.PROTECTION, 3);
        capEnchant(capped, Enchantment.SHARPNESS, 4);
        capEnchant(capped, Enchantment.DENSITY, 4);
        capEnchant(capped, Enchantment.BREACH, 3);
        event.setResult(capped);
    }


    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPotionConsume(org.bukkit.event.player.PlayerItemConsumeEvent event) {
        if (!isPhaseOne()) return;
        ItemStack item = event.getItem();
        if (item == null) return;
        capPotionItem(item);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareSmithing(org.bukkit.event.inventory.PrepareSmithingEvent event) {
        ItemStack base = event.getInventory().getItem(0);
        ItemStack addition = event.getInventory().getItem(2);
        if (base == null || addition == null) return;
        if (addition.getType() != Material.NETHERITE_INGOT) return;

        Material type = base.getType();
        boolean armor = type == Material.DIAMOND_HELMET
                || type == Material.DIAMOND_CHESTPLATE
                || type == Material.DIAMOND_LEGGINGS
                || type == Material.DIAMOND_BOOTS;
        boolean tool = type == Material.DIAMOND_SWORD
                || type == Material.DIAMOND_PICKAXE
                || type == Material.DIAMOND_AXE
                || type == Material.DIAMOND_SHOVEL
                || type == Material.DIAMOND_HOE;

        if (armor || !tool) {
            event.setResult(new ItemStack(Material.AIR));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSmithingClickBlockArmor(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getView().getTopInventory() == null) return;
        if (event.getView().getTopInventory().getType() != InventoryType.SMITHING) return;
        if (event.getRawSlot() != 3) return;

        Inventory smith = event.getView().getTopInventory();
        ItemStack base = smith.getItem(0);
        ItemStack addition = smith.getItem(2);
        if (base == null || addition == null) return;
        if (addition.getType() != Material.NETHERITE_INGOT) return;

        Material type = base.getType();
        boolean armor = type == Material.DIAMOND_HELMET
                || type == Material.DIAMOND_CHESTPLATE
                || type == Material.DIAMOND_LEGGINGS
                || type == Material.DIAMOND_BOOTS;
        boolean tool = type == Material.DIAMOND_SWORD
                || type == Material.DIAMOND_PICKAXE
                || type == Material.DIAMOND_AXE
                || type == Material.DIAMOND_SHOVEL
                || type == Material.DIAMOND_HOE;

        if (armor || !tool) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "Only diamond tools can be upgraded to netherite on this server.");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpecialInventoryClick(InventoryClickEvent event) {
        if (REVIVE_MENU_TITLE.equals(event.getView().getTitle())) return;
        Inventory top = event.getView().getTopInventory();
        if (top == null) return;
        InventoryType type = top.getType();
        if (!isRestrictedInventory(type)) return;

        if (isCustomPluginItem(event.getCursor()) || isCustomPluginItem(event.getCurrentItem())) {
            if (event.getWhoClicked() instanceof Player player) {
                player.sendMessage(ChatColor.RED + "You cannot use custom core items in that menu.");
            }
        }
        if (isPhaseOne() && event.getWhoClicked() instanceof Player player) {
            Bukkit.getScheduler().runTask(this, () -> enforcePhaseOneRestrictions(player));
        }
    }


    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        TestSession session = activeTests.get(event.getPlayer().getUniqueId());
        if (session != null) {
            event.setDropItems(false);
            session.placedBlocks.add(event.getBlock().getLocation());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        TestSession session = activeTests.get(event.getPlayer().getUniqueId());
        if (session != null) {
            session.placedBlocks.add(event.getBlockPlaced().getLocation());
        }
        if (isCustomPluginItem(event.getItemInHand())) {
            event.getPlayer().sendMessage(ChatColor.RED + "That custom item cannot be placed.");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemMerge(ItemMergeEvent event) {
        if (isCustomPluginItem(event.getEntity().getItemStack()) || isCustomPluginItem(event.getTarget().getItemStack())) {
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player) {
            if (isCustomPluginItem(event.getItem().getItemStack())) {
                Bukkit.getScheduler().runTask(this, () -> sanitizeInventory(player));
            }
            if (isPhaseOne()) {
                Bukkit.getScheduler().runTask(this, () -> enforcePhaseOneRestrictions(player));
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemDrop(PlayerDropItemEvent event) {
        ItemStack dropped = event.getItemDrop().getItemStack();
        if (getMaceId(dropped) != null) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(ChatColor.RED + "You cannot drop your mace.");
            return;
        }
        if (isCustomPluginItem(dropped) && dropped.getAmount() > 1) {
            dropped.setAmount(1);
            event.getItemDrop().setItemStack(dropped);
            Bukkit.getScheduler().runTask(this, () -> sanitizeInventory(event.getPlayer()));
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            refreshPassiveEffects(player);
            if (event.getCause() == EntityDamageEvent.DamageCause.FALL && isHoldingWindMace(player)) {
            }
        }

    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        TestSession testSession = activeTests.get(victim.getUniqueId());
        if (testSession != null) {
            event.getDrops().clear();
            event.setKeepInventory(true);
            event.setKeepLevel(true);
            handleTestRoundDeath(victim);
            return;
        }
        storePlayerName(victim);
        rememberAssignedMace(victim);
        event.getDrops().removeIf(this::isCustomPluginItem);

        int energyBeforeDeath = getEnergy(victim.getUniqueId());
        int energyLeft = Math.max(0, energyBeforeDeath - 1);
        setEnergy(victim.getUniqueId(), victim.getName(), energyLeft);

        Player killer = victim.getKiller();
        if (killer != null && !killer.getUniqueId().equals(victim.getUniqueId())) {
            int killerEnergy = getEnergy(killer.getUniqueId());
            if (killerEnergy < getMaxEnergy()) {
                int gained = killerEnergy + 1;
                setEnergy(killer.getUniqueId(), killer.getName(), gained);
                killer.sendMessage(ChatColor.GREEN + "You absorbed 1 energy from killing " + victim.getName() + ". Energy: " + gained + "/" + getMaxEnergy());
                refreshMaceLore(killer);
            } else {
                killer.getWorld().dropItemNaturally(victim.getLocation(), createEnergyBottle());
                killer.sendMessage(ChatColor.GREEN + "You got an Energy Bottle for killing " + victim.getName() + ".");
            }
        }

        if (energyBeforeDeath <= 0) {
            markReviveBanned(victim.getName(), true);
            Bukkit.getBanList(BanList.Type.NAME).addBan(victim.getName(), "Out of energy. Needs a Revive Beacon.", null, "BlissMaces");
            Bukkit.getScheduler().runTask(this, () -> victim.kickPlayer(ChatColor.RED + "You died at 0 energy and are banned until someone revives you with a Revive Beacon."));
            Bukkit.broadcastMessage(ChatColor.DARK_RED + victim.getName() + ChatColor.RED + " died at 0 energy and now needs a Revive Beacon.");
        } else if (energyLeft <= 0) {
            victim.sendMessage(ChatColor.RED + "You hit 0 energy. Your mace is now dormant.");
        } else {
            victim.sendMessage(ChatColor.YELLOW + "Energy lost on death. Energy left: " + energyLeft + "/" + getMaxEnergy());
        }
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Fireball fireball) || !fireball.hasMetadata(FIREBALL_META)) {
            return;
        }
        UUID shooterId = getShooterId(fireball);
        Location loc = fireball.getLocation();
        World world = fireball.getWorld();
        world.createExplosion(loc, 1.15f, false, true);
        world.spawnParticle(Particle.FLAME, loc, 45, 0.45, 0.45, 0.45, 0.08);
        world.spawnParticle(Particle.LAVA, loc, 24, 0.35, 0.25, 0.35, 0.02);
        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.85f);

        for (Entity nearby : world.getNearbyEntities(loc, 3.0, 3.0, 3.0)) {
            if (nearby instanceof LivingEntity living && (shooterId == null || !nearby.getUniqueId().equals(shooterId))) {
                if (event.getHitEntity() != null && nearby.getUniqueId().equals(event.getHitEntity().getUniqueId())) {
                    living.damage(12.0);
                } else {
                    living.damage(8.0);
                }
                living.setFireTicks(Math.max(living.getFireTicks(), 140));
            }
        }
        fireball.remove();
    }

    @EventHandler
    public void onFireballDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Fireball fireball && fireball.hasMetadata(FIREBALL_META)) {
        }

        if (isFrozen(event.getEntity().getUniqueId())) {
            Bukkit.getScheduler().runTask(this, () -> event.getEntity().setVelocity(new Vector(0, 0, 0)));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onMaceItemDamage(PlayerItemDamageEvent event) {
        ItemStack item = event.getItem();
        if (getMaceId(item) == null) return;

        // Keep maces from actually losing durability from use; visual damage is synced manually from energy.
        Bukkit.getScheduler().runTaskLater(this, () -> refreshPlayerMaceModelStates(event.getPlayer()), 1L);
    }

    @EventHandler(ignoreCancelled = true)
    public void onMeleeHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;

        String activeMace = getActiveMaceId(attacker);
        if (isZeroEnergyDisabled(attacker)) {
            return;
        }
        if (activeMace == null) return;

        if (WRATH_ID.equals(activeMace)) {
            event.setDamage(event.getDamage() * getWrathDamageMultiplier(attacker));
        }

        if (LUCK_ID.equals(activeMace)) {
            handleLuckHit(attacker, target, event);
        }

        if (VOID_ID.equals(activeMace)) {
            target.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 0, true, true, true));
        }

        if (hasCopiedMace(attacker)) {
            decrementCopiedHits(attacker);
        }

        if (!JESTER_ID.equals(activeMace)) return;

        int hits = jesterHitCount.getOrDefault(attacker.getUniqueId(), 0) + 1;
        jesterHitCount.put(attacker.getUniqueId(), hits);

        if (hits % 5 == 0) {
            triggerJesterDebuff(attacker, target);
            if (target instanceof Player targetPlayer) {
                triggerJesterCopy(attacker, targetPlayer);
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onKnockback(EntityKnockbackByEntityEvent event) {
        if (event.getEntity() instanceof Player player && playerHasMace(player, WARDEN_ID)) {
            return;
        }
        if (isFrozen(event.getEntity().getUniqueId())) {
            Bukkit.getScheduler().runTask(this, () -> event.getEntity().setVelocity(new Vector(0, 0, 0)));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPearlTeleport(org.bukkit.event.player.PlayerTeleportEvent event) {
        if (event.getCause() == org.bukkit.event.player.PlayerTeleportEvent.TeleportCause.ENDER_PEARL && hasStarted()) {
            event.setCancelled(true);
            event.getPlayer().sendActionBar(ChatColor.RED + "Ender pearls are disabled on this server.");
        }
    }



    @EventHandler(ignoreCancelled = true)
    public void onPotionEffect(EntityPotionEffectEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!playerHasMace(player, WARDEN_ID)) return;
        PotionEffect newEffect = event.getNewEffect();
        if (newEffect == null) return;
        PotionEffectType type = newEffect.getType();
        if (type == PotionEffectType.DARKNESS || type == PotionEffectType.BLINDNESS) {
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onFallDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (playerHasMace(player, WIND_ID)) {
            event.setCancelled(true);
            return;
        }
        if (playerHasMace(player, VOID_ID)) {
            event.setDamage(event.getDamage() * 0.4);
        }
    }

    @EventHandler
    public void onDragonDeath(EntityDeathEvent event) {
        if (!(event.getEntity() instanceof EnderDragon)) return;
        if (!isPhaseOne()) return;
        setPhase(PHASE_TWO);
        Bukkit.broadcastMessage(ChatColor.LIGHT_PURPLE + "Phase 2 has begun. Enchantment restrictions are gone.");
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendMessage(ChatColor.GREEN + "Phase 2 is now active. Enchantment caps have been lifted.");
            refreshDragonEggBuff(player);
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (duneTrapped.contains(event.getPlayer().getUniqueId())) {
            if (event.getFrom().distanceSquared(event.getTo()) > 0.001) {
                event.setTo(event.getFrom());
            }
        }

        Player player = event.getPlayer();
        refreshPassiveEffects(player);
        if (!isFrozen(player.getUniqueId())) return;

        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;

        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            Location locked = from.clone();
            locked.setYaw(to.getYaw());
            locked.setPitch(to.getPitch());
            event.setTo(locked);
        }
    }

    private void useFireMace(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.fire-seconds");
        if (onCooldown(fireCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, fireCooldown, cooldownMs);
            return;
        }

        Vector direction = player.getEyeLocation().getDirection().normalize();
        SmallFireball fireball = player.launchProjectile(SmallFireball.class);
        fireball.setVelocity(direction.multiply(1.7));
        fireball.setIsIncendiary(false);
        fireball.setYield(0f);
        fireball.setMetadata(FIREBALL_META, new FixedMetadataValue(this, player.getUniqueId().toString()));

        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
        player.getWorld().spawnParticle(Particle.FLAME, player.getEyeLocation(), 50, 0.18, 0.18, 0.18, 0.03);
        player.getWorld().spawnParticle(Particle.SMOKE, player.getEyeLocation(), 12, 0.08, 0.08, 0.08, 0.01);

        fireCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, fireCooldown, cooldownMs, cooldownKey(FIRE_ID, "fireball"), "Fireball");
    }

    private void useFireAura(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.fire-aura-seconds");
        if (onCooldown(fireAuraCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, fireAuraCooldown, cooldownMs);
            return;
        }

        fireAuraCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, fireAuraCooldown, cooldownMs, cooldownKey(FIRE_ID, "inferno"), "Inferno Aura");
        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1f, 0.85f);
        world.spawnParticle(Particle.LAVA, player.getLocation().add(0, 0.15, 0), 16, 0.35, 0.05, 0.35, 0.0);
        player.sendMessage(ChatColor.GOLD + "Inferno Aura ignited for 6 seconds.");

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }

                Location center = player.getLocation().add(0, 0.15, 0);
                double radius = 3.2;
                double spin = ticks * 0.18;
                for (int i = 0; i < 40; i++) {
                    double angle = (Math.PI * 2 * i) / 32.0 + spin;
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    world.spawnParticle(Particle.FLAME, center.clone().add(x, 0.05, z), 2, 0.02, 0.02, 0.02, 0);
                    world.spawnParticle(Particle.DUST, center.clone().add(x, 0.12, z), 1, 0, 0, 0, new Particle.DustOptions(Color.fromRGB(255, 120, 20), 1.4f));
                }
                for (int i = 0; i < 24; i++) {
                    double angle = (Math.PI * 2 * i) / 24.0 - spin * 0.7;
                    double x = Math.cos(angle) * (radius * 0.72);
                    double z = Math.sin(angle) * (radius * 0.72);
                    world.spawnParticle(Particle.SMALL_FLAME, center.clone().add(x, 0.45, z), 1, 0, 0, 0, 0);
                }
                for (int i = 0; i < 20; i++) {
                    double angle = (Math.PI * 2 * i) / 20.0 + spin * 1.2;
                    double x = Math.cos(angle) * (radius * 0.42);
                    double z = Math.sin(angle) * (radius * 0.42);
                    world.spawnParticle(Particle.LAVA, center.clone().add(x, 0.9, z), 1, 0, 0, 0, 0);
                }
                world.spawnParticle(Particle.FLAME, center.clone().add(0, 0.2, 0), 8, 0.25, 0.12, 0.25, 0.01);

                if (ticks % 10 == 0) {
                    AttributeInstance maxHealth = player.getAttribute(Attribute.MAX_HEALTH);
                    double cap = maxHealth != null ? maxHealth.getValue() : 20.0;
                    player.setFireTicks(0);
                    player.setHealth(Math.min(cap, player.getHealth() + 1.0));

                    for (Entity nearby : world.getNearbyEntities(center, radius, 1.8, radius)) {
                        if (!(nearby instanceof LivingEntity living) || nearby.getUniqueId().equals(player.getUniqueId())) continue;
                        living.damage(3.0, player);
                        living.setFireTicks(Math.max(living.getFireTicks(), 60));
                    }
                }

                ticks += 2;
                if (ticks >= 120) {
                    world.playSound(player.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 0.8f, 0.9f);
                    cancel();
                }
            }
        }.runTaskTimer(this, 0L, 2L);
    }

    private void useWindMace(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.wind-seconds");
        if (onCooldown(windCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, windCooldown, cooldownMs);
            return;
        }

        Vector direction = player.getEyeLocation().getDirection().normalize();
        Vector launch = direction.multiply(2.15);
        launch.setY(Math.max(0.55, Math.min(1.05, launch.getY() + 0.45)));
        player.setFallDistance(0f);
        player.setVelocity(launch);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WIND_CHARGE_WIND_BURST, 1f, 1.1f);
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation().add(0, 1, 0), 45, 0.35, 0.35, 0.35, 0.06);
        player.getWorld().spawnParticle(Particle.GUST, player.getLocation().add(0, 1, 0), 16, 0.4, 0.4, 0.4, 0.01);
        player.removePotionEffect(PotionEffectType.SLOW_FALLING);
        clearWrathEffects(player);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            player.removePotionEffect(PotionEffectType.SLOW_FALLING);
        clearWrathEffects(player);
            player.setFallDistance(0f);
        }, 2L);

        windCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, windCooldown, cooldownMs, cooldownKey(WIND_ID, "dash"), "Wind Dash");
    }

    private void useZeusLightning(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.zeus-lightning-seconds");
        if (onCooldown(zeusLightningCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, zeusLightningCooldown, cooldownMs);
            return;
        }

        RayTraceResult trace = player.getWorld().rayTrace(player.getEyeLocation(), player.getLocation().getDirection(), 30.0,
                FluidCollisionMode.NEVER, true, 0.25,
                entity -> entity instanceof LivingEntity && !entity.getUniqueId().equals(player.getUniqueId()));

        Location strikeLoc;
        if (trace != null) {
            if (trace.getHitEntity() != null) {
                strikeLoc = trace.getHitEntity().getLocation();
                ((LivingEntity) trace.getHitEntity()).damage(8.0, player);
            } else if (trace.getHitPosition() != null) {
                strikeLoc = trace.getHitPosition().toLocation(player.getWorld());
            } else {
                strikeLoc = player.getTargetBlockExact(30) != null ? player.getTargetBlockExact(30).getLocation().add(0.5, 1, 0.5) : player.getLocation().add(player.getLocation().getDirection().multiply(8));
            }
        } else {
            strikeLoc = player.getTargetBlockExact(30) != null ? player.getTargetBlockExact(30).getLocation().add(0.5, 1, 0.5) : player.getLocation().add(player.getLocation().getDirection().multiply(8));
        }

        player.getWorld().strikeLightningEffect(strikeLoc);
        player.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, strikeLoc, 40, 0.6, 1.0, 0.6, 0.15);
        player.getWorld().playSound(strikeLoc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1f);
        for (Entity nearby : player.getWorld().getNearbyEntities(strikeLoc, 2.5, 3, 2.5)) {
            if (nearby instanceof LivingEntity living && !nearby.getUniqueId().equals(player.getUniqueId())) {
                living.damage(9.0, player);
            }
        }

        zeusLightningCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, zeusLightningCooldown, cooldownMs, cooldownKey(ZEUS_ID, "lightning"), "Lightning");
    }

    private void useZeusLock(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.zeus-lock-seconds");
        if (onCooldown(zeusLockCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, zeusLockCooldown, cooldownMs);
            return;
        }

        LivingEntity target = findTarget(player, 25);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "No target in sight.");
            return;
        }

        freezeEntity(target, 60L);
        target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, target.getLocation().add(0, 1, 0), 50, 0.4, 0.8, 0.4, 0.08);
        target.getWorld().playSound(target.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1f, 0.7f);
        if (target instanceof Player targetPlayer) {
            targetPlayer.sendMessage(ChatColor.AQUA + "Zeus locked you in place for 3 seconds.");
            sendEnemyAbilityTitle(targetPlayer, "The sky chose you", "Zeus pinned you where you stand");
        }
        player.sendMessage(ChatColor.GOLD + "Target locked for 3 seconds.");

        zeusLockCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, zeusLockCooldown, cooldownMs, cooldownKey(ZEUS_ID, "lock"), "Zeus Lock");
    }



    private void sendEnemyAbilityTitle(Player target, String title, String subtitle) {
        target.sendTitle(
                ChatColor.DARK_RED + title,
                ChatColor.RED + subtitle,
                5, 35, 10
        );
    }

    private void triggerJesterDebuff(Player attacker, LivingEntity target) {
        long cooldownMs = 30_000L;
        if (onCooldown(jesterDebuffCooldown, attacker.getUniqueId(), cooldownMs)) return;

        List<PotionEffectType> debuffs = List.of(
                PotionEffectType.SLOWNESS,
                PotionEffectType.WEAKNESS,
                PotionEffectType.POISON,
                PotionEffectType.BLINDNESS,
                PotionEffectType.MINING_FATIGUE,
                PotionEffectType.NAUSEA
        );
        PotionEffectType type = debuffs.get(random.nextInt(debuffs.size()));
        int duration = switch (type.getKey().getKey()) {
            case "poison" -> 60;
            case "blindness" -> 50;
            default -> 80;
        };
        target.addPotionEffect(new PotionEffect(type, duration, 0, true, true, true));
        attacker.getWorld().spawnParticle(Particle.WITCH, target.getLocation().add(0, 1, 0), 18, 0.35, 0.45, 0.35, 0.02);
        attacker.sendMessage(ChatColor.LIGHT_PURPLE + "Ringmaster applied " + ChatColor.YELLOW + prettifyPotion(type) + ChatColor.LIGHT_PURPLE + ".");
        if (target instanceof Player targetPlayer) {
            targetPlayer.sendMessage(ChatColor.RED + "The Jester Mace cursed you with " + prettifyPotion(type) + ".");
            sendEnemyAbilityTitle(targetPlayer, "Fate laughed at you", "Ringmaster dealt " + prettifyPotion(type));
        }
        jesterDebuffCooldown.put(attacker.getUniqueId(), System.currentTimeMillis());
    }

    private void triggerJesterCopy(Player attacker, Player target) {
        long cooldownMs = 70_000L;
        if (onCooldown(jesterCopyCooldown, attacker.getUniqueId(), cooldownMs)) return;

        ItemStack targetItem = target.getInventory().getItemInMainHand();
        String targetMace = getActiveMaceId(target);
        if (targetMace == null || JESTER_ID.equals(targetMace)) return;

        UUID uuid = attacker.getUniqueId();
        if (!jesterOriginalMace.containsKey(uuid)) {
            jesterOriginalMace.put(uuid, JESTER_ID);
        }
        Map<Enchantment, Integer> copiedEnchants = new HashMap<>();
        if (targetItem != null) {
            copiedEnchants.putAll(targetItem.getEnchantments());
        }
        jesterCopiedEnchantments.put(uuid, copiedEnchants);
        jesterCopyHitsLeft.put(uuid, 4);
        setAssignedMaceId(uuid, targetMace);
        giveAssignedMaceInstant(attacker);
        applyCopiedMaceEnchants(attacker);
        attacker.sendMessage(ChatColor.AQUA + "Copycat stole " + readableName(targetMace) + ChatColor.AQUA + " for 4 hits.");
        sendEnemyAbilityTitle(target, "Your edge was stolen", "Copycat mirrored your power");
        jesterCopyCooldown.put(uuid, System.currentTimeMillis());
    }

    private boolean hasCopiedMace(Player player) {
        return jesterCopyHitsLeft.getOrDefault(player.getUniqueId(), 0) > 0;
    }

    private void decrementCopiedHits(Player player) {
        UUID uuid = player.getUniqueId();
        int left = jesterCopyHitsLeft.getOrDefault(uuid, 0);
        if (left <= 0) return;
        left--;
        if (left <= 0) {
            jesterCopyHitsLeft.remove(uuid);
            jesterCopiedEnchantments.remove(uuid);
            String original = jesterOriginalMace.remove(uuid);
            if (original == null) original = JESTER_ID;
            setAssignedMaceId(uuid, original);
            giveAssignedMaceInstant(player);
            player.sendMessage(ChatColor.LIGHT_PURPLE + "Copycat faded. Your Jester Mace returned.");
        } else {
            jesterCopyHitsLeft.put(uuid, left);
        }
    }

    private void applyCopiedMaceEnchants(Player player) {
        Map<Enchantment, Integer> copied = jesterCopiedEnchantments.get(player.getUniqueId());
        if (copied == null || copied.isEmpty()) return;
        ItemStack main = player.getInventory().getItemInMainHand();
        if (main == null || getMaceId(main) == null) return;
        for (Map.Entry<Enchantment, Integer> entry : copied.entrySet()) {
            try {
                main.addUnsafeEnchantment(entry.getKey(), entry.getValue());
            } catch (Exception ignored) {
            }
        }
    }


    private void cacheJesterOriginalEnchantState(Player player, ItemStack jester) {
        if (player == null || jester == null) return;
        Map<Enchantment, Integer> stored = new HashMap<>(jester.getEnchantments());
        jesterOriginalEnchants.put(player.getUniqueId(), stored);
        if (jester.hasItemMeta()) {
            ItemMeta meta = jester.getItemMeta();
        }
    }

    private void restoreJesterOriginalEnchantState(Player player, ItemStack jester) {
        if (player == null || jester == null) return;
        Map<Enchantment, Integer> stored = jesterOriginalEnchants.remove(player.getUniqueId());
        ItemMeta meta = jester.getItemMeta();
        if (meta == null) return;

        for (Enchantment ench : new HashSet<>(jester.getEnchantments().keySet())) {
            jester.removeEnchantment(ench);
        }
        if (stored != null) {
            for (Map.Entry<Enchantment, Integer> entry : stored.entrySet()) {
                jester.addUnsafeEnchantment(entry.getKey(), entry.getValue());
            }
        }
    }


    private void useWardenSlam(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.warden-slam-seconds");
        if (onCooldown(wardenSlamCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, wardenSlamCooldown, cooldownMs);
            return;
        }

        Location center = player.getLocation().clone();
        World world = player.getWorld();
        world.playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 1f, 0.7f);
        world.spawnParticle(Particle.SONIC_BOOM, center.clone().add(0, 1, 0), 1);
        world.spawnParticle(Particle.ASH, center.clone().add(0, 0.2, 0), 30, 0.8, 0.1, 0.8, 0.02);
        for (int i = 0; i < 36; i++) {
            double angle = (Math.PI * 2 * i) / 36.0;
            double x = Math.cos(angle) * 4.5;
            double z = Math.sin(angle) * 4.5;
            world.spawnParticle(Particle.DUST, center.clone().add(x, 0.2, z), 1, 0, 0, 0,
                    new Particle.DustOptions(Color.fromRGB(50, 50, 50), 1.4f));
        }
        for (Entity nearby : world.getNearbyEntities(center, 4.5, 2.5, 4.5)) {
            if (nearby instanceof LivingEntity living && !nearby.getUniqueId().equals(player.getUniqueId())) {
                living.damage(10.0, player);
                Vector away = living.getLocation().toVector().subtract(center.toVector()).normalize().multiply(1.3).setY(0.4);
                living.setVelocity(away);
            }
        }
        wardenSlamCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, wardenSlamCooldown, cooldownMs, cooldownKey(WARDEN_ID, "slam"), "Warden Slam");
    }

    private void useWardenDarkness(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.warden-darkness-seconds");
        if (onCooldown(wardenDarknessCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, wardenDarknessCooldown, cooldownMs);
            return;
        }

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.ENTITY_WARDEN_NEARBY_CLOSE, 1f, 0.6f);
        for (Entity nearby : world.getNearbyEntities(player.getLocation(), 8, 4, 8)) {
            if (nearby instanceof LivingEntity living && !nearby.getUniqueId().equals(player.getUniqueId())) {
                living.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 100, 0, true, true, true));
                if (living instanceof Player targetPlayer) {
                    sendEnemyAbilityTitle(targetPlayer, "The cave swallowed the light", "Warden buried you in darkness");
                }
            }
        }
        wardenDarknessCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, wardenDarknessCooldown, cooldownMs, cooldownKey(WARDEN_ID, "darkness"), "Warden Darkness");
    }

    private void useVoidBlink(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.void-blink-seconds");
        if (onCooldown(voidBlinkCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, voidBlinkCooldown, cooldownMs);
            return;
        }

        Location from = player.getLocation().clone();
        Vector dir = player.getLocation().getDirection().normalize();
        Location to = from.clone().add(dir.multiply(6));
        if (to.getWorld().getBlockAt(to).isSolid()) {
            to = from.clone().add(dir.multiply(4));
        }
        to.setDirection(player.getLocation().getDirection());
        player.teleport(to);
        player.getWorld().spawnParticle(Particle.PORTAL, from.clone().add(0, 1, 0), 50, 0.4, 0.6, 0.4, 0.2);
        player.getWorld().spawnParticle(Particle.PORTAL, to.clone().add(0, 1, 0), 50, 0.4, 0.6, 0.4, 0.2);
        player.getWorld().playSound(to, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.7f);

        for (Entity nearby : player.getWorld().getNearbyEntities(to, 3.5, 2.5, 3.5)) {
            if (nearby instanceof LivingEntity living && !nearby.getUniqueId().equals(player.getUniqueId())) {
                living.damage(9.0, player);
                living.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 80, 0, true, true, true));
            }
        }
        voidBlinkCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, voidBlinkCooldown, cooldownMs, cooldownKey(VOID_ID, "blink"), "Void Blink");
    }

    private void useVoidPull(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.void-pull-seconds");
        if (onCooldown(voidPullCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, voidPullCooldown, cooldownMs);
            return;
        }

        Location center = player.getLocation().clone();
        World world = player.getWorld();
        world.playSound(center, Sound.BLOCK_PORTAL_AMBIENT, 1f, 0.5f);
        world.spawnParticle(Particle.REVERSE_PORTAL, center.clone().add(0, 1, 0), 90, 2.5, 1.2, 2.5, 0.06);
        world.spawnParticle(Particle.PORTAL, center.clone().add(0, 0.3, 0), 35, 1.8, 0.3, 1.8, 0.02);
        for (Entity nearby : world.getNearbyEntities(center, 7, 4, 7)) {
            if (nearby instanceof LivingEntity living && !nearby.getUniqueId().equals(player.getUniqueId())) {
                Vector pull = center.toVector().subtract(living.getLocation().toVector()).normalize().multiply(1.25).setY(0.2);
                living.setVelocity(pull);
                living.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 0, true, true, true));
            }
        }
        voidPullCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, voidPullCooldown, cooldownMs, cooldownKey(VOID_ID, "pull"), "Void Pull");
    }


    private Player getTargetPlayer(Player player, double range) {
        RayTraceResult result = player.getWorld().rayTraceEntities(
                player.getEyeLocation(),
                player.getEyeLocation().getDirection(),
                range,
                entity -> entity instanceof Player && !entity.getUniqueId().equals(player.getUniqueId())
        );
        if (result == null || !(result.getHitEntity() instanceof Player target)) return null;
        return target;
    }

    private void useVisionBlind(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.vision-blind-seconds");
        if (onCooldown(visionBlindCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, visionBlindCooldown, cooldownMs);
            return;
        }
        Player target = getTargetPlayer(player, 20.0);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "No enemy in sight.");
            return;
        }
        target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20 * 10, 0, true, true, true));
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 20 * 10, 1, true, true, true));
        sendEnemyAbilityTitle(target, "Your world went dim", "Vision tore the light away");
        player.getWorld().playSound(target.getLocation(), Sound.ENTITY_ILLUSIONER_CAST_SPELL, 1f, 0.7f);
        visionBlindCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, visionBlindCooldown, cooldownMs, cooldownKey(VISION_ID, "blind"), "Blind");
    }

    private void useVisionVoid(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.vision-void-seconds");
        if (onCooldown(visionVoidCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, visionVoidCooldown, cooldownMs);
            return;
        }
        Player target = getTargetPlayer(player, 20.0);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "No enemy in sight.");
            return;
        }
        target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 20 * 3, 1, true, false, true));
        target.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 20 * 3, 0, true, false, true));
        target.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20 * 3, 0, true, false, true));
        for (Entity nearby : target.getWorld().getNearbyEntities(target.getLocation(), 12, 12, 12)) {
            if (nearby instanceof Player p && !p.getUniqueId().equals(target.getUniqueId())) {
                p.hidePlayer(this, target);
                Bukkit.getScheduler().runTaskLater(this, () -> p.showPlayer(this, target), 20L * 3);
            }
        }
        sendEnemyAbilityTitle(target, "Nothingness found you", "The void erased everything around you");
        target.getWorld().playSound(target.getLocation(), Sound.AMBIENT_CAVE, 1f, 0.5f);
        visionVoidCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, visionVoidCooldown, cooldownMs, cooldownKey(VISION_ID, "veil"), "Void Veil");
    }

    private void useDuneWave(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.dune-wave-seconds");
        if (onCooldown(duneWaveCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, duneWaveCooldown, cooldownMs);
            return;
        }
        Location center = player.getLocation().clone();
        World world = player.getWorld();
        world.playSound(center, Sound.BLOCK_SAND_BREAK, 1f, 0.6f);
        world.spawnParticle(Particle.CLOUD, center.clone().add(0, 0.1, 0), 24, 0.8, 0.1, 0.8, 0.03);
        for (int i = 0; i < 28; i++) {
            double angle = (Math.PI * 2 * i) / 28.0;
            double x = Math.cos(angle) * 5.0;
            double z = Math.sin(angle) * 5.0;
            world.spawnParticle(Particle.FALLING_DUST, center.clone().add(x, 0.2, z), 4, 0.1, 0.1, 0.1, Material.SAND.createBlockData());
        }
        for (Entity nearby : world.getNearbyEntities(center, 5.0, 2.5, 5.0)) {
            if (nearby instanceof LivingEntity living && !nearby.getUniqueId().equals(player.getUniqueId())) {
                living.damage(7.0, player);
                Vector away = living.getLocation().toVector().subtract(center.toVector()).normalize().multiply(1.0).setY(0.25);
                living.setVelocity(away);
            }
        }
        duneWaveCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, duneWaveCooldown, cooldownMs, cooldownKey(DUNE_ID, "wave"), "Sand Wave");
    }

    private void useDunePit(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.dune-pit-seconds");
        if (onCooldown(dunePitCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, dunePitCooldown, cooldownMs);
            return;
        }
        Location center = player.getLocation().clone();
        World world = player.getWorld();
        world.playSound(center, Sound.BLOCK_SAND_FALL, 1f, 0.6f);
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                for (Entity nearby : world.getNearbyEntities(center, 3.0, 2.0, 3.0)) {
                    if (nearby instanceof LivingEntity living && !nearby.getUniqueId().equals(player.getUniqueId())) {
                        duneTrapped.add(living.getUniqueId());
                        world.spawnParticle(Particle.FALLING_DUST, living.getLocation().clone().add(0, 0.1, 0), 8, 0.3, 0.1, 0.3, Material.SAND.createBlockData());
                        living.setVelocity(new Vector(0, -0.08, 0));
                        if (living instanceof Player targetPlayer && ticks == 1) {
                            sendEnemyAbilityTitle(targetPlayer, "The desert took your step", "Quicksand dragged you under");
                        }
                    }
                }
                if (ticks >= 40) {
                    for (UUID id : new HashSet<>(duneTrapped)) {
                        duneTrapped.remove(id);
                    }
                    cancel();
                }
            }
        }.runTaskTimer(this, 0L, 1L);
        dunePitCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, dunePitCooldown, cooldownMs, cooldownKey(DUNE_ID, "pit"), "Quicksand Pit");
    }


    private void dropVillagerEnergyBottle(Villager villager, Player killer) {
        if (villager == null || killer == null) return;
        villager.getWorld().dropItemNaturally(villager.getLocation(), createEnergyBottle());
    }

    private String prettifyPotion(PotionEffectType type) {
        String raw = type.getKey().getKey().replace('_', ' ');
        StringBuilder sb = new StringBuilder();
        for (String part : raw.split(" ")) {
            if (part.isEmpty()) continue;
            if (!sb.isEmpty()) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }


    private double getWrathDamageMultiplier(Player player) {
        AttributeInstance attr = player.getAttribute(Attribute.MAX_HEALTH);
        double maxHealth = attr != null ? Math.max(1.0, attr.getValue()) : 20.0;
        double health = Math.max(0.0, player.getHealth());
        double missingRatio = 1.0 - (health / maxHealth);
        return 1.0 + missingRatio;
    }

    private void updateWrathBar(Player player) {
        if (!player.isOnline()) return;
        boolean hasWrath = playerHasMace(player, WRATH_ID);
        BossBar bar = wrathBars.get(player.getUniqueId());
        if (!hasWrath) {
            if (bar != null) {
                bar.removeAll();
                wrathBars.remove(player.getUniqueId());
            }
            return;
        }

        AttributeInstance attr = player.getAttribute(Attribute.MAX_HEALTH);
        double maxHealth = attr != null ? Math.max(1.0, attr.getValue()) : 20.0;
        double health = Math.max(0.0, player.getHealth());
        double missingRatio = Math.max(0.0, Math.min(1.0, 1.0 - (health / maxHealth)));
        double multiplier = getWrathDamageMultiplier(player);

        if (bar == null) {
            bar = Bukkit.createBossBar("", BarColor.RED, BarStyle.SEGMENTED_10);
            bar.addPlayer(player);
            wrathBars.put(player.getUniqueId(), bar);
        } else if (!bar.getPlayers().contains(player)) {
            bar.addPlayer(player);
        }

        bar.setVisible(true);
        bar.setProgress(Math.max(0.0, Math.min(1.0, missingRatio)));
        bar.setTitle(ChatColor.DARK_RED + "Berserker " + ChatColor.GRAY + "x" + String.format(java.util.Locale.US, "%.2f", multiplier));
    }

    private void useWrathBloodhunt(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.wrath-bloodhunt-seconds");
        if (onCooldown(wrathBloodhuntCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, wrathBloodhuntCooldown, cooldownMs);
            return;
        }

        wrathBloodhuntCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, wrathBloodhuntCooldown, cooldownMs, cooldownKey(WRATH_ID, "bloodhunt"), "Bloodhunt");

        int durationTicks = (int) Math.round(getConfig().getDouble("durations.wrath-bloodhunt-seconds", 10.0) * 20.0);
        player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, durationTicks, 1, false, false, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, durationTicks, 1, false, false, true));

        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.ENTITY_WARDEN_HEARTBEAT, 1.0f, 0.8f);
        world.spawnParticle(Particle.DUST, player.getLocation().add(0, 1.0, 0), 60, 0.6, 0.8, 0.6, new Particle.DustOptions(Color.fromRGB(180, 0, 0), 1.8f));

        markWrathTargets(player, 20.0);
        player.sendMessage(ChatColor.DARK_RED + "Bloodhunt awakened.");

        Bukkit.getScheduler().runTaskLater(this, () -> clearWrathEffects(player), durationTicks);
    }

    private void markWrathTargets(Player caster, double radius) {
        clearWrathEffects(caster);
        Scoreboard board = Bukkit.getScoreboardManager() != null ? Bukkit.getScoreboardManager().getMainScoreboard() : null;
        Team team = null;
        if (board != null) {
            team = board.getTeam("core_wrath_red");
            if (team == null) {
                team = board.registerNewTeam("core_wrath_red");
                team.setColor(ChatColor.RED);
            }
        }

        Set<UUID> marked = new HashSet<>();
        for (Entity entity : caster.getNearbyEntities(radius, radius, radius)) {
            if (!(entity instanceof Player target)) continue;
            if (target.equals(caster)) continue;
            target.setGlowing(true);
            if (team != null) team.addEntry(target.getName());
            marked.add(target.getUniqueId());
        }
        wrathMarkedPlayers.put(caster.getUniqueId(), marked);
    }

    private void clearWrathEffects(Player caster) {
        BossBar bar = wrathBars.get(caster.getUniqueId());
        if (bar != null && !playerHasMace(caster, WRATH_ID)) {
            bar.removeAll();
            wrathBars.remove(caster.getUniqueId());
        }

        Set<UUID> marked = wrathMarkedPlayers.remove(caster.getUniqueId());
        Team team = null;
        if (Bukkit.getScoreboardManager() != null) {
            team = Bukkit.getScoreboardManager().getMainScoreboard().getTeam("core_wrath_red");
        }
        if (marked != null) {
            for (UUID uuid : marked) {
                Player target = Bukkit.getPlayer(uuid);
                if (target == null) continue;
                target.setGlowing(false);
                if (team != null) team.removeEntry(target.getName());
            }
        }
    }


    private double getLuckBuffChance(Player player) {
        UUID uuid = player.getUniqueId();
        int backfires = luckBackfireStreak.getOrDefault(uuid, 0);
        int shockwaves = luckShockwaveStreak.getOrDefault(uuid, 0);
        double chance = 0.50 + Math.min(0.35, backfires * 0.075) - Math.min(0.40, shockwaves * 0.10);
        return Math.max(0.05, Math.min(0.95, chance));
    }

    private void updateLuckBar(Player player) {
        BossBar bar = luckBars.get(player.getUniqueId());
        if (!playerHasMace(player, LUCK_ID)) {
            if (bar != null) {
                bar.removeAll();
                luckBars.remove(player.getUniqueId());
            }
            return;
        }
        if (bar == null) {
            bar = Bukkit.createBossBar("", BarColor.GREEN, BarStyle.SEGMENTED_10);
            bar.addPlayer(player);
            luckBars.put(player.getUniqueId(), bar);
        } else if (!bar.getPlayers().contains(player)) {
            bar.addPlayer(player);
        }
        double buffChance = getLuckBuffChance(player);
        double debuffChance = 1.0 - buffChance;
        bar.setVisible(true);
        bar.setProgress(Math.max(0.0, Math.min(1.0, buffChance)));
        bar.setTitle(ChatColor.GREEN + "Luck Meter " + ChatColor.GRAY + (int)Math.round(buffChance * 100) + "% buff / " + (int)Math.round(debuffChance * 100) + "% backfire");
    }

    private void removeLuckBar(Player player) {
        BossBar bar = luckBars.remove(player.getUniqueId());
        if (bar != null) {
            bar.removeAll();
        }
    }

    private void useLuckCoinToss(Player player) {
        if (isZeroEnergyDisabled(player)) return;
        long cooldownMs = getCooldownMs("cooldowns.luck-coin-seconds");
        if (onCooldown(luckCoinCooldown, player.getUniqueId(), cooldownMs)) {
            sendCooldown(player, luckCoinCooldown, cooldownMs);
            return;
        }
        long armedMs = Math.round(getConfig().getDouble("durations.luck-armed-seconds", 10.0) * 1000.0);
        luckCoinCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        announceReadyLater(player, luckCoinCooldown, cooldownMs, cooldownKey(LUCK_ID, "coin"), "Coin Toss");
        luckArmedUntil.put(player.getUniqueId(), System.currentTimeMillis() + armedMs);
        player.sendMessage(ChatColor.GREEN + "Coin Toss armed. Your next mace hit will roll luck.");
        player.getWorld().playSound(player.getLocation(), Sound.UI_TOAST_IN, 0.8f, 1.3f);
        player.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation().add(0, 1, 0), 10, 0.4, 0.6, 0.4, 0.05);
    }

    private void handleLuckHit(Player attacker, LivingEntity target, EntityDamageByEntityEvent event) {
        long armedUntil = luckArmedUntil.getOrDefault(attacker.getUniqueId(), 0L);
        if (armedUntil < System.currentTimeMillis()) return;
        luckArmedUntil.remove(attacker.getUniqueId());

        double buffChance = getLuckBuffChance(attacker);
        boolean shockwave = random.nextDouble() < buffChance;
        if (shockwave) {
            triggerLuckShockwave(attacker, event);
        } else {
            triggerLuckBackfire(attacker, event);
        }
        updateLuckBar(attacker);
    }

    private void triggerLuckShockwave(Player attacker, EntityDamageByEntityEvent event) {
        UUID uuid = attacker.getUniqueId();
        luckShockwaveStreak.put(uuid, luckShockwaveStreak.getOrDefault(uuid, 0) + 1);
        luckBackfireStreak.remove(uuid);

        event.setDamage(event.getDamage() * 1.65);
        double roll = random.nextDouble();
        if (roll < 0.05) {
            attacker.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 20 * 15, 1, true, true, true));
            attacker.sendMessage(ChatColor.GREEN + "Coin Toss: SUPER BUFF — Resistance II for 15s.");
        } else {
            int pick = random.nextInt(3);
            switch (pick) {
                case 0 -> {
                    attacker.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 20 * 15, 2, true, true, true));
                    attacker.sendMessage(ChatColor.GREEN + "Coin Toss: Shockwave — Strength III for 15s.");
                }
                case 1 -> {
                    attacker.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 20 * 5, 2, true, true, true));
                    attacker.sendMessage(ChatColor.GREEN + "Coin Toss: Shockwave — Regeneration III for 5s.");
                }
                default -> {
                    double max = attacker.getAttribute(Attribute.MAX_HEALTH) != null ? attacker.getAttribute(Attribute.MAX_HEALTH).getValue() : 20.0;
                    attacker.setHealth(Math.min(max, attacker.getHealth() + 8.0));
                    attacker.sendMessage(ChatColor.GREEN + "Coin Toss: Shockwave — Instant Health III.");
                }
            }
        }
        attacker.getWorld().playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.9f, 1.2f);
        attacker.getWorld().spawnParticle(Particle.CRIT, attacker.getLocation().add(0, 1, 0), 28, 0.45, 0.45, 0.45, 0.1);
    }

    private void triggerLuckBackfire(Player attacker, EntityDamageByEntityEvent event) {
        UUID uuid = attacker.getUniqueId();
        luckBackfireStreak.put(uuid, luckBackfireStreak.getOrDefault(uuid, 0) + 1);
        luckShockwaveStreak.remove(uuid);

        event.setDamage(event.getDamage() * 0.55);
        double roll = random.nextDouble();
        if (roll < 0.05) {
            attacker.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 20 * 15, 2, true, true, true));
            attacker.sendMessage(ChatColor.RED + "Coin Toss: SUPER DEBUFF — Weakness III for 15s.");
        } else {
            int pick = random.nextInt(4);
            switch (pick) {
                case 0 -> {
                    attacker.damage(random.nextBoolean() ? 4.0 : 6.0);
                    attacker.sendMessage(ChatColor.RED + "Coin Toss: Backfire — Instant Harm.");
                }
                case 1 -> {
                    attacker.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 20 * 15, 3, true, true, true));
                    attacker.sendMessage(ChatColor.RED + "Coin Toss: Backfire — Slowness IV for 15s.");
                }
                case 2 -> {
                    attacker.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 20 * 10, 0, true, true, true));
                    attacker.sendMessage(ChatColor.RED + "Coin Toss: Backfire — Nausea for 10s.");
                }
                default -> {
                    attacker.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 20 * 15, 3, true, true, true));
                    attacker.sendMessage(ChatColor.RED + "Coin Toss: Backfire — Mining Fatigue IV for 15s.");
                }
            }
        }
        attacker.getWorld().playSound(attacker.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.9f, 0.8f);
        attacker.getWorld().spawnParticle(Particle.SMOKE, attacker.getLocation().add(0, 1, 0), 22, 0.45, 0.45, 0.45, 0.03);
    }

    private void registerRecipes() {
        Bukkit.removeRecipe(new NamespacedKey(this, "core_repair_kit"));
        Bukkit.removeRecipe(new NamespacedKey(this, "core_mace_trader"));
        Bukkit.removeRecipe(new NamespacedKey(this, "core_revive_beacon"));

        ShapedRecipe repair = new ShapedRecipe(new NamespacedKey(this, "core_repair_kit"), createRepairKit());
        repair.shape("ABA", "BCB", "ABA");
        repair.setIngredient('A', Material.NETHERITE_BLOCK);
        repair.setIngredient('B', Material.ANVIL);
        repair.setIngredient('C', Material.NETHER_STAR);
        Bukkit.addRecipe(repair);

        ShapedRecipe trader = new ShapedRecipe(new NamespacedKey(this, "core_mace_trader"), createMaceTrader());
        trader.shape("ABA", "BCB", "ABA");
        trader.setIngredient('A', Material.NETHERITE_SWORD);
        trader.setIngredient('B', Material.TOTEM_OF_UNDYING);
        trader.setIngredient('C', Material.BEACON);
        Bukkit.addRecipe(trader);

        ShapedRecipe revive = new ShapedRecipe(new NamespacedKey(this, "core_revive_beacon"), createReviveBeacon());
        revive.shape("ABA", "BCB", "ABA");
        revive.setIngredient('A', Material.END_CRYSTAL);
        revive.setIngredient('B', Material.NETHERITE_BLOCK);
        revive.setIngredient('C', Material.ENDER_CHEST);
        Bukkit.addRecipe(revive);
    }

    private void openRecipeMenu(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 27, RECIPE_MENU_TITLE);
        ItemStack filler = createMenuFiller();
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }

        inventory.setItem(11, createRecipePreview(Material.ANVIL, ChatColor.WHITE + "Repair Kit", List.of(
                ChatColor.GRAY + "Click to see the full crafting layout",
                ChatColor.DARK_GRAY + "Crafts a Repair Kit"
        )));

        inventory.setItem(13, createRecipePreview(Material.NETHERITE_SWORD, ChatColor.LIGHT_PURPLE + "Mace Trader", List.of(
                ChatColor.GRAY + "Click to see the full crafting layout",
                ChatColor.DARK_GRAY + "Crafts a Mace Trader"
        )));

        inventory.setItem(15, createRecipePreview(Material.BEACON, ChatColor.AQUA + "Revive Beacon", List.of(
                ChatColor.GRAY + "Click to see the full crafting layout",
                ChatColor.DARK_GRAY + "Crafts a Revive Beacon"
        )));

        player.openInventory(inventory);
        player.playSound(player.getLocation(), Sound.UI_CARTOGRAPHY_TABLE_TAKE_RESULT, 0.8f, 1.15f);
    }

    private void openRecipeDetailMenu(Player player, String recipeId) {
        String title;
        Material[] grid = new Material[9];
        ItemStack result;

        switch (recipeId.toLowerCase(Locale.ROOT)) {
            case "repair" -> {
                title = RECIPE_DETAIL_PREFIX + ChatColor.WHITE + "Repair Kit";
                grid = new Material[]{
                        Material.NETHERITE_BLOCK, Material.ANVIL, Material.NETHERITE_BLOCK,
                        Material.ANVIL, Material.NETHER_STAR, Material.ANVIL,
                        Material.NETHERITE_BLOCK, Material.ANVIL, Material.NETHERITE_BLOCK
                };
                result = createRepairKit();
            }
            case "trader" -> {
                title = RECIPE_DETAIL_PREFIX + ChatColor.LIGHT_PURPLE + "Mace Trader";
                grid = new Material[]{
                        Material.NETHERITE_SWORD, Material.TOTEM_OF_UNDYING, Material.NETHERITE_SWORD,
                        Material.TOTEM_OF_UNDYING, Material.BEACON, Material.TOTEM_OF_UNDYING,
                        Material.NETHERITE_SWORD, Material.TOTEM_OF_UNDYING, Material.NETHERITE_SWORD
                };
                result = createMaceTrader();
            }
            case "revive" -> {
                title = RECIPE_DETAIL_PREFIX + ChatColor.AQUA + "Revive Beacon";
                grid = new Material[]{
                        Material.END_CRYSTAL, Material.NETHERITE_BLOCK, Material.END_CRYSTAL,
                        Material.NETHERITE_BLOCK, Material.ENDER_CHEST, Material.NETHERITE_BLOCK,
                        Material.END_CRYSTAL, Material.NETHERITE_BLOCK, Material.END_CRYSTAL
                };
                result = createReviveBeacon();
            }
            default -> {
                player.sendMessage(ChatColor.RED + "Unknown recipe.");
                return;
            }
        }

        Inventory inventory = Bukkit.createInventory(null, 45, title);
        ItemStack filler = createMenuFiller();
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }

        int[] gridSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        for (int i = 0; i < grid.length; i++) {
            inventory.setItem(gridSlots[i], new ItemStack(grid[i]));
        }

        inventory.setItem(24, createRecipePreview(Material.CRAFTING_TABLE, ChatColor.GOLD + "3x3 Crafting Layout", List.of(
                ChatColor.GRAY + "This shows the exact crafting grid",
                ChatColor.DARK_GRAY + "Just like a crafting table"
        )));
        inventory.setItem(25, result);
        inventory.setItem(40, createRecipePreview(Material.BOOK, ChatColor.GOLD + "Back to recipes", List.of(ChatColor.GRAY + "Click to return to the recipe list.")));

        player.openInventory(inventory);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.9f, 1.05f);
    }

    private ItemStack createRecipePreview(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(name);
        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    private void openReviveMenu(Player player) {
        if (!ITEM_REVIVE.equals(getSpecialItemId(player.getInventory().getItemInMainHand()))) {
            player.sendMessage(ChatColor.RED + "Hold a Revive Beacon in your main hand.");
            return;
        }

        List<OfflinePlayer> bannedPlayers = getReviveBannedPlayers();
        if (bannedPlayers.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "Nobody is currently waiting for a Revive Beacon.");
            return;
        }

        int size = Math.min(54, Math.max(9, ((bannedPlayers.size() - 1) / 9 + 1) * 9));
        Inventory inventory = Bukkit.createInventory(null, size, REVIVE_MENU_TITLE);

        ItemStack filler = createMenuFiller();
        for (int slot = 0; slot < size; slot++) {
            inventory.setItem(slot, filler);
        }

        for (int i = 0; i < Math.min(size, bannedPlayers.size()); i++) {
            inventory.setItem(i, createReviveHead(bannedPlayers.get(i)));
        }

        player.openInventory(inventory);
        player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 1.2f);
    }


    private ItemStack createMenuFiller() {
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        meta.setDisplayName(ChatColor.GRAY + " ");
        meta.setLore(List.of(ChatColor.DARK_GRAY + "Use a player head to revive someone."));
        filler.setItemMeta(meta);
        return filler;
    }

    private ItemStack createReviveHead(OfflinePlayer target) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(target);
        String name = target.getName() == null ? "Unknown" : target.getName();
        meta.setDisplayName(ChatColor.AQUA + name);
        meta.setLore(List.of(
                ChatColor.GRAY + "Click to revive this player.",
                ChatColor.GRAY + "Consumes your Revive Beacon.",
                ChatColor.DARK_GRAY + "Energy after revive: 2/" + getMaxEnergy()
        ));
        meta.getPersistentDataContainer().set(specialItemKey, PersistentDataType.STRING, ITEM_REVIVE + "_TARGET:" + name.toLowerCase(Locale.ROOT));
        head.setItemMeta(meta);
        return head;
    }

    private List<OfflinePlayer> getReviveBannedPlayers() {
        List<OfflinePlayer> bannedPlayers = new ArrayList<>();
        if (!getConfig().isConfigurationSection("revive-banned")) {
            return bannedPlayers;
        }

        for (String key : getConfig().getConfigurationSection("revive-banned").getKeys(false)) {
            if (!getConfig().getBoolean("revive-banned." + key, false)) continue;
            String exactName = findStoredPlayerName(key);
            OfflinePlayer offline = exactName != null ? Bukkit.getOfflinePlayer(exactName) : Bukkit.getOfflinePlayer(key);
            bannedPlayers.add(offline);
        }

        bannedPlayers.sort(Comparator.comparing(p -> {
            String name = p.getName();
            return name == null ? "zzzz" : name.toLowerCase(Locale.ROOT);
        }));
        return bannedPlayers;
    }

    private String findStoredPlayerName(String lowerName) {
        if (!getConfig().isConfigurationSection("players")) return null;
        for (String uuidKey : getConfig().getConfigurationSection("players").getKeys(false)) {
            String name = getConfig().getString("players." + uuidKey + ".name");
            if (name != null && name.equalsIgnoreCase(lowerName)) {
                return name;
            }
        }
        return lowerName;
    }

    private void revivePlayerByName(String targetName, CommandSender sender) {
        Bukkit.getBanList(BanList.Type.NAME).pardon(targetName);
        markReviveBanned(targetName, false);
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        UUID uuid = target.getUniqueId();
        setEnergy(uuid, targetName, 2);
        sender.sendMessage(ChatColor.GREEN + targetName + " was revived and restored to 2/" + getMaxEnergy() + " energy.");
        Player online = Bukkit.getPlayerExact(targetName);
        if (online != null) {
            online.sendMessage(ChatColor.AQUA + "You have been revived.");
        }
        Bukkit.broadcastMessage(ChatColor.AQUA + targetName + ChatColor.GREEN + " has been revived.");
    }

    private void useMaceTrader(Player player) {
        if (!consumeHeldSpecialItem(player, ITEM_TRADER)) return;
        removeAllCustomMaces(player);
        giveRandomMaceWithCircle(player);
        player.sendMessage(ChatColor.LIGHT_PURPLE + "Mace Trader used. Your mace was respun.");
    }

    private void useRepairKit(Player player) {
        ItemStack target = findRepairableMace(player.getInventory());
        if (target == null) {
            player.sendMessage(ChatColor.RED + "Hold or carry a damaged custom mace to use a Repair Kit.");
            return;
        }
        if (!(target.getItemMeta() instanceof Damageable damageable)) {
            player.sendMessage(ChatColor.RED + "That item cannot be repaired.");
            return;
        }
        int currentEnergy = getEnergy(player.getUniqueId());
        boolean needsDurabilityRepair = damageable.getDamage() > 0;
        boolean needsEnergyRepair = currentEnergy < getMaxEnergy();

        if (!needsDurabilityRepair && !needsEnergyRepair) {
            player.sendMessage(ChatColor.RED + "That mace is already fully repaired.");
            return;
        }
        if (!consumeHeldSpecialItem(player, ITEM_REPAIR)) return;

        damageable.setDamage(0);
        target.setItemMeta((ItemMeta) damageable);
        setEnergy(player.getUniqueId(), player.getName(), getMaxEnergy());
        refreshMaceLore(player);
        refreshPassiveEffects(player);

        player.sendMessage(ChatColor.GREEN + "Your mace has been fully repaired and your energy was restored to full.");
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 1f, 1.2f);
    }

    private void useEnergyBottle(Player player) {
        int current = getEnergy(player.getUniqueId());
        if (current >= getMaxEnergy()) {
            player.sendMessage(ChatColor.YELLOW + "Your energy is already full.");
            return;
        }
        if (!consumeHeldSpecialItem(player, ITEM_ENERGY)) return;
        int updated = Math.min(getMaxEnergy(), current + 1);
        setEnergy(player.getUniqueId(), player.getName(), updated);
        player.sendMessage(ChatColor.GREEN + "Energy restored. You now have " + updated + "/" + getMaxEnergy() + " energy.");
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
    }

    private void freezeEntity(LivingEntity entity, long durationTicks) {
        UUID uuid = entity.getUniqueId();
        frozenUntil.put(uuid, System.currentTimeMillis() + (durationTicks * 50L));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) durationTicks, 10, true, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, (int) durationTicks, 2, true, false, false));
        entity.setVelocity(new Vector(0, 0, 0));

        if (entity instanceof Player player) {
            savedWalkSpeed.putIfAbsent(uuid, player.getWalkSpeed());
            player.setWalkSpeed(0f);
        }

        AttributeInstance kb = entity.getAttribute(Attribute.KNOCKBACK_RESISTANCE);
        Double oldValue = kb != null ? kb.getBaseValue() : null;
        if (kb != null) kb.setBaseValue(1.0);

        new BukkitRunnable() {
            long left = durationTicks;

            @Override
            public void run() {
                if (!entity.isValid() || left-- <= 0 || !isFrozen(uuid)) {
                    if (kb != null && oldValue != null) kb.setBaseValue(oldValue);
                    cleanupFrozenPlayer(entity);
                    frozenUntil.remove(uuid);
                    cancel();
                    return;
                }
                entity.setVelocity(new Vector(0, 0, 0));
                entity.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, entity.getLocation().add(0, 1, 0), 5, 0.25, 0.4, 0.25, 0.02);
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    private void cleanupFrozenPlayer(Entity entity) {
        if (entity instanceof Player player) {
            Float old = savedWalkSpeed.remove(player.getUniqueId());
            if (old != null) {
                player.setWalkSpeed(old);
            }
        }
    }

    private boolean isFrozen(UUID uuid) {
        Long until = frozenUntil.get(uuid);
        if (until == null) return false;
        if (System.currentTimeMillis() > until) {
            frozenUntil.remove(uuid);
            Player online = Bukkit.getPlayer(uuid);
            if (online != null) cleanupFrozenPlayer(online);
            return false;
        }
        return true;
    }

    private LivingEntity findTarget(Player player, double range) {
        RayTraceResult trace = player.getWorld().rayTrace(player.getEyeLocation(), player.getLocation().getDirection(), range,
                FluidCollisionMode.NEVER, true, 0.3,
                entity -> entity instanceof LivingEntity && !entity.getUniqueId().equals(player.getUniqueId()));
        if (trace != null && trace.getHitEntity() instanceof LivingEntity living) {
            return living;
        }
        return null;
    }

    private void giveRandomMaceWithCircle(Player player) {
        removeAllCustomMaces(player);
        String chosenId = randomMaceId();
        setAssignedMaceId(player.getUniqueId(), chosenId);
        playSpawnCircle(player);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            ItemStack mace = createMaceFromId(chosenId, player);
            player.getInventory().addItem(mace);
            sanitizeInventory(player);
            player.sendMessage(ChatColor.LIGHT_PURPLE + "The circle chose: " + ChatColor.GOLD + readableName(getMaceId(mace)));
            refreshPassiveEffects(player);
            refreshMaceLore(player);
            refreshPlayerMaceModelStates(player);
        }, 1L);
    }

    private void playSpawnCircle(Player player) {
        Location center = player.getLocation().clone().add(0, 0.1, 0);
        new BukkitRunnable() {
            double radius = 2.7;
            int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || ticks++ > 26) {
                    cancel();
                    return;
                }
                for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 12) {
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    Location loc = center.clone().add(x, 0.1, z);
                    player.getWorld().spawnParticle(Particle.ENCHANT, loc, 2, 0, 0, 0, 0);
                    player.getWorld().spawnParticle(Particle.END_ROD, loc, 1, 0, 0, 0, 0);
                }
                player.getWorld().playSound(center, Sound.BLOCK_BEACON_AMBIENT, 0.6f, 1.4f);
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    private ItemStack createRandomMace() {
        return createMaceFromId(randomMaceId(), null);
    }

    private String randomMaceId() {
        List<String> ids = new ArrayList<>(List.of(FIRE_ID, WIND_ID, ZEUS_ID, JESTER_ID, WRATH_ID, LUCK_ID, WARDEN_ID, VOID_ID, VISION_ID, DUNE_ID));
        List<Integer> weights = new ArrayList<>();
        int total = 0;
        for (String id : ids) {
            int owners = countAssignedOwners(id);
            int weight = Math.max(1, 10 - owners * 2);
            weights.add(weight);
            total += weight;
        }
        int roll = random.nextInt(total);
        int running = 0;
        for (int i = 0; i < ids.size(); i++) {
            running += weights.get(i);
            if (roll < running) return ids.get(i);
        }
        return JESTER_ID;
    }

    private int countAssignedOwners(String maceId) {
        int count = 0;
        ConfigurationSection players = getConfig().getConfigurationSection("players");
        if (players == null) return 0;
        for (String key : players.getKeys(false)) {
            if (maceId.equals(players.getString(key + ".assigned-mace"))) count++;
        }
        return count;
    }

    private ItemStack createMaceFromId(String maceId, Player owner) {
        return switch (maceId) {
            case FIRE_ID -> createFireMace(owner);
            case WIND_ID -> createWindMace(owner);
            case ZEUS_ID -> createZeusMace(owner);
            case JESTER_ID -> createJesterMace(owner);
            case WRATH_ID -> createWrathMace(owner);
            case LUCK_ID -> createLuckMace(owner);
            case WARDEN_ID -> createWardenMace(owner);
            case VOID_ID -> createVoidMace(owner);
            case VISION_ID -> createVisionMace(owner);
            case DUNE_ID -> createDuneMace(owner);
            default -> createJesterMace(owner);
        };
    }

    private ItemStack createFireMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.RED + "Fire Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, FIRE_ID);
        item.setItemMeta(meta);
        item.addUnsafeEnchantment(Enchantment.FIRE_ASPECT, 2);
        decorateMace(item, owner);
        return item;
    }

    private ItemStack createWindMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.AQUA + "Wind Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, WIND_ID);
        item.setItemMeta(meta);
        item.addUnsafeEnchantment(Enchantment.WIND_BURST, 2);
        decorateMace(item, owner);
        return item;
    }

    private ItemStack createZeusMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.YELLOW + "Zeus Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, ZEUS_ID);
        item.setItemMeta(meta);
        decorateMace(item, owner);
        return item;
    }

    private ItemStack createJesterMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "Jester Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, JESTER_ID);
        item.setItemMeta(meta);
        decorateMace(item, owner);
        return item;
    }

    private ItemStack createWrathMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.DARK_RED + "Wrath Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, WRATH_ID);
        item.setItemMeta(meta);
        decorateMace(item, owner);
        return item;
    }

    private ItemStack createLuckMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.GREEN + "Luck Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, LUCK_ID);
        item.setItemMeta(meta);
        decorateMace(item, owner);
        return item;
    }


    private ItemStack createWardenMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.DARK_GRAY + "Warden Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, WARDEN_ID);
        item.setItemMeta(meta);
        item.addUnsafeEnchantment(Enchantment.BREACH, 3);
        decorateMace(item, owner);
        return item;
    }

    private ItemStack createVoidMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.DARK_PURPLE + "Void Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, VOID_ID);
        item.setItemMeta(meta);
        item.addUnsafeEnchantment(Enchantment.DENSITY, 3);
        decorateMace(item, owner);
        return item;
    }


    private ItemStack createVisionMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "Vision Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, VISION_ID);
        item.setItemMeta(meta);
        decorateMace(item, owner);
        return item;
    }

    private ItemStack createDuneMace(Player owner) {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(ChatColor.GOLD + "Dune Mace");
        applyHiddenEnchantStyle(meta);
        meta.getPersistentDataContainer().set(maceIdKey, PersistentDataType.STRING, DUNE_ID);
        item.setItemMeta(meta);
        decorateMace(item, owner);
        return item;
    }

    private ItemStack createMaceTrader() {
        return createSpecialItem(Material.AMETHYST_SHARD, ChatColor.LIGHT_PURPLE + "Mace Trader",
                List.of(ChatColor.GRAY + "Right click to reroll your mace.", ChatColor.GRAY + "Consumes itself on use."), ITEM_TRADER);
    }

    private ItemStack createReviveBeacon() {
        return createSpecialItem(Material.BEACON, ChatColor.AQUA + "Revive Beacon",
                List.of(ChatColor.GRAY + "Right click to open the revive menu.", ChatColor.GRAY + "Click a banned player head to revive them."), ITEM_REVIVE);
    }

    private ItemStack createRepairKit() {
        return createSpecialItem(Material.IRON_INGOT, ChatColor.WHITE + "Repair Kit",
                List.of(ChatColor.GRAY + "Right click to fully repair a damaged custom mace."), ITEM_REPAIR);
    }

    private ItemStack createEnergyBottle() {
        return createSpecialItem(Material.HONEY_BOTTLE, ChatColor.GREEN + "Energy Bottle",
                List.of(ChatColor.GRAY + "Right click to restore 1 energy.", ChatColor.GRAY + "Drops from player kills only."), ITEM_ENERGY);
    }

    private ItemStack createSpecialItem(Material material, String name, List<String> lore, String id) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setDisplayName(name);
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(specialItemKey, PersistentDataType.STRING, id);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createMaceByName(String maceName) {
        return createMaceByName(maceName, null);
    }

    private ItemStack createMaceByName(String maceName, Player owner) {
        return switch (maceName.toLowerCase(Locale.ROOT)) {
            case "fire" -> createFireMace(owner);
            case "wind" -> createWindMace(owner);
            case "zeus" -> createZeusMace(owner);
            case "jester", "jest" -> createJesterMace(owner);
            case "wrath" -> createWrathMace(owner);
            case "luck" -> createLuckMace(owner);
            case "warden" -> createWardenMace(owner);
            case "void" -> createVoidMace(owner);
            case "vision" -> createVisionMace(owner);
            case "dune" -> createDuneMace(owner);
            case "random" -> createMaceFromId(randomMaceId(), owner);
            default -> null;
        };
    }

    private ItemStack createSpecialByName(String itemName) {
        return switch (itemName.toLowerCase(Locale.ROOT)) {
            case "trader", "macetrader" -> createMaceTrader();
            case "revive", "revivebeacon" -> createReviveBeacon();
            case "repair", "repairkit" -> createRepairKit();
            case "energy", "energybottle" -> createEnergyBottle();
            default -> null;
        };
    }

    private boolean isCustomMace(ItemStack item) {
        return getMaceId(item) != null;
    }

    private boolean isSpecialCoreItem(ItemStack item) {
        return getSpecialItemId(item) != null;
    }

    private boolean isCustomPluginItem(ItemStack item) {
        return isCustomMace(item) || isSpecialCoreItem(item);
    }

    private boolean isRestrictedInventory(InventoryType type) {
        return type == InventoryType.CARTOGRAPHY
                || type == InventoryType.STONECUTTER
                || type == InventoryType.LOOM
                || type == InventoryType.MERCHANT;
    }

    private void sanitizeInventory(Player player) {
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack item = inventory.getItem(slot);
            if (!isCustomPluginItem(item) || item == null) continue;
            if (item.getAmount() <= 1) continue;

            int amount = item.getAmount();
            item.setAmount(1);
            inventory.setItem(slot, item);
            for (int i = 1; i < amount; i++) {
                HashMap<Integer, ItemStack> leftovers = inventory.addItem(item.clone());
                leftovers.values().forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
            }
        }
        player.updateInventory();
    }

    private String getMaceId(ItemStack item) {
        if (item == null || item.getType() != Material.MACE || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(maceIdKey, PersistentDataType.STRING);
    }

    private String getSpecialItemId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(specialItemKey, PersistentDataType.STRING);
    }

    private String readableName(String id) {
        return switch (id) {
            case FIRE_ID -> "Fire Mace";
            case WIND_ID -> "Wind Mace";
            case ZEUS_ID -> "Zeus Mace";
            case JESTER_ID -> "Jester Mace";
            case WRATH_ID -> "Wrath Mace";
            case LUCK_ID -> "Luck Mace";
            case WARDEN_ID -> "Warden Mace";
            case VOID_ID -> "Void Mace";
            case VISION_ID -> "Vision Mace";
            case DUNE_ID -> "Dune Mace";
            default -> "Unknown Mace";
        };
    }

    private void refreshPassiveEffects(Player player) {
        if (isZeroEnergyDisabled(player)) {
            refreshDragonEggBuff(player);
            updateWrathBar(player);
            updateLuckBar(player);
            return;
        }

        PotionEffect fireRes = player.getPotionEffect(PotionEffectType.FIRE_RESISTANCE);
        if (playerHasMace(player, FIRE_ID) && (fireRes == null || fireRes.getAmplifier() < 0 || fireRes.getDuration() < 40)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 60, 0, true, false, false));
        }

        PotionEffect speed = player.getPotionEffect(PotionEffectType.SPEED);
        if (playerHasMace(player, ZEUS_ID) && (speed == null || speed.getAmplifier() < 0 || speed.getDuration() < 40)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, 0, true, false, false));
        }

        if (playerHasMace(player, WARDEN_ID)) {
            player.removePotionEffect(PotionEffectType.DARKNESS);
            player.removePotionEffect(PotionEffectType.BLINDNESS);
        }

        if (playerHasMace(player, WIND_ID)) {
            player.removePotionEffect(PotionEffectType.SLOW_FALLING);
            clearWrathEffects(player);
        }

        refreshDragonEggBuff(player);
        updateWrathBar(player);
        updateLuckBar(player);
    }

    private boolean playerHasMace(Player player, String maceId) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (maceId.equals(getMaceId(item))) return true;
        }
        return maceId.equals(getMaceId(player.getInventory().getItemInOffHand()));
    }

    private String getActiveMaceId(Player player) {
        String main = getMaceId(player.getInventory().getItemInMainHand());
        if (main != null) return main;
        for (ItemStack item : player.getInventory().getContents()) {
            String id = getMaceId(item);
            if (id != null) return id;
        }
        return getMaceId(player.getInventory().getItemInOffHand());
    }

    private void refreshDragonEggBuff(Player player) {
        AttributeInstance maxHealth = player.getAttribute(Attribute.MAX_HEALTH);
        if (maxHealth == null) return;

        double target = player.getInventory().contains(Material.DRAGON_EGG) ? 40.0 : 20.0;
        if (Math.abs(maxHealth.getBaseValue() - target) < 0.01) return;

        maxHealth.setBaseValue(target);
        if (player.getHealth() > target) {
            player.setHealth(target);
        }
    }

    private boolean isHoldingFireMace(Player player) {
        return playerHasMace(player, FIRE_ID);
    }

    private boolean isHoldingWindMace(Player player) {
        return playerHasMace(player, WIND_ID);
    }

    private boolean onCooldown(Map<UUID, Long> map, UUID uuid, long cooldownMs) {
        long now = System.currentTimeMillis();
        return map.containsKey(uuid) && (now - map.get(uuid) < cooldownMs);
    }


    private String formatCooldownLeft(Map<UUID, Long> map, Player player, long cooldownMs) {
        long started = map.getOrDefault(player.getUniqueId(), 0L);
        if (started <= 0L) return ChatColor.GREEN + "Ready";
        long elapsed = System.currentTimeMillis() - started;
        double left = Math.max(0.0, (cooldownMs - elapsed) / 1000.0);
        if (left <= 0.0) return ChatColor.GREEN + "Ready";
        return ChatColor.RED + String.format(Locale.US, "%.1fs", left);
    }

    private void updateHeldMaceCooldownBar(Player player) {
        if (player == null || !player.isOnline()) return;
        if (isZeroEnergyDisabled(player)) {
            player.sendActionBar(ChatColor.DARK_RED + "Dormant " + ChatColor.GRAY + "- 0 energy");
            return;
        }

        ItemStack held = player.getInventory().getItemInMainHand();
        String maceId = getMaceId(held);
        if (maceId == null) return;

        String text;
        switch (maceId) {
            case FIRE_ID -> text = ChatColor.GOLD + "✦ Fireball " + formatCooldownLeft(fireCooldown, player, getCooldownMs("cooldowns.fire-seconds"))
                    + ChatColor.DARK_GRAY + " • "
                    + ChatColor.GOLD + "Inferno Aura " + formatCooldownLeft(fireAuraCooldown, player, getCooldownMs("cooldowns.fire-aura-seconds"));
            case WIND_ID -> text = ChatColor.AQUA + "✦ Wind Dash " + formatCooldownLeft(windCooldown, player, getCooldownMs("cooldowns.wind-seconds"));
            case ZEUS_ID -> text = ChatColor.YELLOW + "✦ Lightning " + formatCooldownLeft(zeusLightningCooldown, player, getCooldownMs("cooldowns.zeus-lightning-seconds"))
                    + ChatColor.DARK_GRAY + " • "
                    + ChatColor.YELLOW + "Zeus Lock " + formatCooldownLeft(zeusLockCooldown, player, getCooldownMs("cooldowns.zeus-lock-seconds"));
            case WRATH_ID -> text = ChatColor.DARK_RED + "✦ Bloodhunt " + formatCooldownLeft(wrathBloodhuntCooldown, player, getCooldownMs("cooldowns.wrath-bloodhunt-seconds"));
            case LUCK_ID -> text = ChatColor.LIGHT_PURPLE + "✦ Coin Toss " + formatCooldownLeft(luckCoinCooldown, player, getCooldownMs("cooldowns.luck-coin-seconds"));
            case WARDEN_ID -> text = ChatColor.DARK_GRAY + "✦ Slam " + formatCooldownLeft(wardenSlamCooldown, player, getCooldownMs("cooldowns.warden-slam-seconds"))
                    + ChatColor.DARK_GRAY + " • "
                    + ChatColor.GRAY + "Darkness " + formatCooldownLeft(wardenDarknessCooldown, player, getCooldownMs("cooldowns.warden-darkness-seconds"));
            case VOID_ID -> text = ChatColor.DARK_PURPLE + "✦ Blink " + formatCooldownLeft(voidBlinkCooldown, player, getCooldownMs("cooldowns.void-blink-seconds"))
                    + ChatColor.DARK_GRAY + " • "
                    + ChatColor.DARK_PURPLE + "Pull " + formatCooldownLeft(voidPullCooldown, player, getCooldownMs("cooldowns.void-pull-seconds"));
            case VISION_ID -> text = ChatColor.DARK_PURPLE + "✦ Blind " + formatCooldownLeft(visionBlindCooldown, player, getCooldownMs("cooldowns.vision-blind-seconds"))
                    + ChatColor.DARK_GRAY + " • "
                    + ChatColor.BLACK + "Void Veil " + formatCooldownLeft(visionVoidCooldown, player, getCooldownMs("cooldowns.vision-void-seconds"));
            case DUNE_ID -> text = ChatColor.GOLD + "✦ Sand Wave " + formatCooldownLeft(duneWaveCooldown, player, getCooldownMs("cooldowns.dune-wave-seconds"))
                    + ChatColor.DARK_GRAY + " • "
                    + ChatColor.YELLOW + "Quicksand " + formatCooldownLeft(dunePitCooldown, player, getCooldownMs("cooldowns.dune-pit-seconds"));
            default -> {
                return;
            }
        }
        player.sendActionBar(text);
    }

        private final Map<UUID, Map<String, Boolean>> cooldownReadyFlags = new HashMap<>();

    private String stylizeHeader(String text) {
        return ChatColor.DARK_GRAY + "╔═ " + ChatColor.LIGHT_PURPLE + text + ChatColor.DARK_GRAY + " ═╗";
    }

    private String formatAbilityLine(String title, String body) {
        return ChatColor.LIGHT_PURPLE + "◆ " + ChatColor.WHITE + title + ChatColor.GRAY + " • " + body;
    }

    private String formatPassiveLine(String title, String body) {
        return ChatColor.AQUA + "◇ " + ChatColor.WHITE + title + ChatColor.GRAY + " • " + body;
    }

    private String formatEnergyLine(int energy) {
        return ChatColor.DARK_GRAY + "• " + ChatColor.GRAY + "Energy State: " + ChatColor.WHITE + energyStateName(energy);
    }

    private String cooldownKey(String maceId, String ability) {
        return maceId + ":" + ability;
    }

    private void markCooldownTracking(Player player, String key, boolean ready) {
        cooldownReadyFlags.computeIfAbsent(player.getUniqueId(), id -> new HashMap<>()).put(key, ready);
    }

    private void notifyReadyIfNeeded(Player player, String key, String niceName, boolean readyNow) {
        Map<String, Boolean> flags = cooldownReadyFlags.computeIfAbsent(player.getUniqueId(), id -> new HashMap<>());
        boolean wasReady = flags.getOrDefault(key, true);
        if (!wasReady && readyNow) {
            player.sendMessage(ChatColor.GREEN + "Ability ready: " + ChatColor.YELLOW + niceName + ChatColor.GREEN + ".");
        }
        flags.put(key, readyNow);
    }

    private void announceReadyLater(Player player, Map<UUID, Long> map, long cooldownMs, String key, String niceName) {
        markCooldownTracking(player, key, false);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (player == null || !player.isOnline()) return;
            long started = map.getOrDefault(player.getUniqueId(), 0L);
            long elapsed = System.currentTimeMillis() - started;
            if (started > 0L && elapsed >= cooldownMs) {
                player.sendMessage(ChatColor.GREEN + "Ability ready: " + ChatColor.YELLOW + niceName + ChatColor.GREEN + ".");
                markCooldownTracking(player, key, true);
            }
        }, Math.max(1L, Math.round(cooldownMs / 50.0)));
    }

private void sendCooldown(Player player, Map<UUID, Long> map, long cooldownMs) {
        long elapsed = System.currentTimeMillis() - map.getOrDefault(player.getUniqueId(), 0L);
        double left = Math.max(0, (cooldownMs - elapsed) / 1000.0);
        player.sendActionBar(ChatColor.DARK_GRAY + "✦ " + ChatColor.GOLD + "Cooldown" + ChatColor.DARK_GRAY + " • " + ChatColor.RED + String.format(Locale.US, "%.1fs", left));
    }

    private long getCooldownMs(String path) {
        return Math.round(getConfig().getDouble(path) * 1000.0);
    }

    private UUID getShooterId(Metadatable metaCarrier) {
        try {
            List<org.bukkit.metadata.MetadataValue> values = metaCarrier.getMetadata(FIREBALL_META);
            if (values.isEmpty()) return null;
            return UUID.fromString(values.get(0).asString());
        } catch (Exception ignored) {
            return null;
        }
    }

    private boolean hasStarted() {
        return getConfig().getBoolean("game.started", false);
    }

    private int getPhase() {
        return getConfig().getInt("game.phase", PHASE_NOT_STARTED);
    }

    private boolean isPhaseOne() {
        return getPhase() == PHASE_ONE;
    }

    private void setPhase(int phase) {
        getConfig().set("game.started", phase != PHASE_NOT_STARTED);
        getConfig().set("game.phase", phase);
        saveConfig();
    }

    private void startServerPhaseOne(CommandSender sender) {
        if (hasStarted()) {
            sender.sendMessage(ChatColor.RED + "The server has already been started.");
            return;
        }

        Bukkit.broadcastMessage(ChatColor.DARK_RED + "The gods have awakened...");
        for (int i = 5; i >= 1; i--) {
            final int countdown = i;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                Bukkit.broadcastMessage(ChatColor.GOLD + "The divine maces descend in " + countdown + "...");
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.sendTitle(ChatColor.GOLD + "The Gods Have Spoken",
                            ChatColor.YELLOW + "Divine maces descend in " + countdown + "...",
                            0, 20, 5);
                    player.playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.9f, 1.0f + (5 - countdown) * 0.06f);
                }
            }, (5 - i) * 20L);
        }

        Bukkit.getScheduler().runTaskLater(this, () -> beginPhaseOne(sender), 100L);
    }

    private void beginPhaseOne(CommandSender sender) {
        if (hasStarted()) {
            return;
        }
        setPhase(PHASE_ONE);
        Bukkit.broadcastMessage(ChatColor.GOLD + "The gods created the divine maces and distributed them to the creatures that are called humans.");
        Bukkit.broadcastMessage(ChatColor.YELLOW + "Phase 1 has started. Ender pearls are disabled. Enchant caps are now active.");
        for (Player online : Bukkit.getOnlinePlayers()) {
            storePlayerName(online);
            removeAllCustomMaces(online);
            setAssignedMaceId(online.getUniqueId(), randomMaceId());
            playGlobalMaceEvent(online);
            giveAssignedMaceInstant(online);
            enforcePhaseOneRestrictions(online);
            online.sendMessage(ChatColor.LIGHT_PURPLE + "Your mace has been chosen.");
        }
        if (sender != null) {
            sender.sendMessage(ChatColor.GREEN + "Phase 1 has started.");
        }
    }

    private void playGlobalMaceEvent(Player player) {
        if (player == null || !player.isOnline()) return;
        Location loc = player.getLocation().clone().add(0, 1.0, 0);
        World world = player.getWorld();
        world.strikeLightningEffect(player.getLocation());
        player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 0.75f);
        player.playSound(player.getLocation(), Sound.ITEM_TRIDENT_THUNDER, 0.9f, 1.1f);
        player.sendTitle(ChatColor.GOLD + "✦ The Gods Have Spoken ✦",
                ChatColor.YELLOW + "A divine mace descends from the heavens",
                10, 50, 20);
        for (int step = 0; step < 36; step++) {
            double angle = (Math.PI * 2 * step) / 36.0;
            double x = Math.cos(angle) * 1.6;
            double z = Math.sin(angle) * 1.6;
            world.spawnParticle(Particle.FLAME, loc.clone().add(x, 0.05, z), 1, 0.0, 0.0, 0.0, 0.0);
            world.spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(x, 0.25, z), 1, 0.0, 0.0, 0.0, 0.0);
            world.spawnParticle(Particle.ENCHANT, loc.clone().add(x * 0.7, 0.6, z * 0.7), 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private void enforcePhaseOneRestrictions(Player player) {
        if (player == null) return;
        ItemStack[] contents = player.getInventory().getContents();
        for (ItemStack item : contents) {
            capEnchant(item, Enchantment.PROTECTION, 3);
            capEnchant(item, Enchantment.SHARPNESS, 4);
            capEnchant(item, Enchantment.DENSITY, 4);
            capEnchant(item, Enchantment.BREACH, 3);
        }
        player.updateInventory();
    }


    private void stopCoreGame(CommandSender sender, boolean resetEnergy) {
        setPhase(PHASE_NOT_STARTED);
        for (Player online : Bukkit.getOnlinePlayers()) {
            clearCoreStateForPlayer(online, resetEnergy);
            online.sendMessage(resetEnergy
                    ? ChatColor.RED + "The gods have withdrawn their power. The world has been reset."
                    : ChatColor.RED + "The gods have withdrawn their power. All divine maces have vanished.");
        }

        ConfigurationSection playersSection = getConfig().getConfigurationSection("players");
        if (playersSection != null) {
            for (String uuidKey : playersSection.getKeys(false)) {
                getConfig().set("players." + uuidKey + ".assigned-mace", null);
                if (resetEnergy) {
                    getConfig().set("players." + uuidKey + ".energy", getMaxEnergy());
                }
            }
        }
        saveConfig();

        Bukkit.broadcastMessage(resetEnergy
                ? ChatColor.DARK_RED + "The gods have withdrawn their power and reset the world."
                : ChatColor.DARK_RED + "The gods have withdrawn their power.");

        if (sender != null) {
            sender.sendMessage(ChatColor.GREEN + (resetEnergy ? "Core has been fully reset." : "Core has been stopped."));
        }
    }

    private void removeBossBar(Player player) {
        // Boss bar cleanup hook; no-op if no boss bars are currently tracked.
    }

    private void clearCoreStateForPlayer(Player player, boolean resetEnergy) {
        removeAllCoreItems(player);
        setAssignedMaceId(player.getUniqueId(), null);
        removeBossBar(player);
        player.removePotionEffect(PotionEffectType.SPEED);
        player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        player.removePotionEffect(PotionEffectType.SLOW_FALLING);
        clearWrathEffects(player);
        player.setFireTicks(0);
        player.setFallDistance(0f);
        player.getInventory().setItemInOffHand(null);
        player.setItemOnCursor(null);
        if (resetEnergy) {
            setEnergy(player.getUniqueId(), player.getName(), getMaxEnergy());
        }
        player.updateInventory();
    }

    private void removeAllCoreItems(Player player) {
        PlayerInventory inventory = player.getInventory();
        ItemStack[] contents = inventory.getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isCustomMace(contents[i]) || isSpecialCoreItem(contents[i])) {
                inventory.setItem(i, null);
            }
        }
        ItemStack[] armor = inventory.getArmorContents();
        for (int i = 0; i < armor.length; i++) {
            if (isCustomMace(armor[i]) || isSpecialCoreItem(armor[i])) {
                armor[i] = null;
            }
        }
        inventory.setArmorContents(armor);
        ItemStack off = inventory.getItemInOffHand();
        if (isCustomMace(off) || isSpecialCoreItem(off)) {
            inventory.setItemInOffHand(null);
        }
    }

    private void capEnchantMap(Map<Enchantment, Integer> map, Enchantment enchantment, int cap) {
        Integer level = map.get(enchantment);
        if (level != null && level > cap) {
            map.put(enchantment, cap);
        }
    }


    private void capPotionItem(ItemStack item) {
        if (item == null) return;
        Material t = item.getType();
        if (t != Material.POTION && t != Material.SPLASH_POTION && t != Material.LINGERING_POTION) return;
        if (!(item.getItemMeta() instanceof org.bukkit.inventory.meta.PotionMeta meta)) return;

        org.bukkit.potion.PotionData base = meta.getBasePotionData();
        if (base == null) return;
        if (base.isUpgraded()) {
            meta.setBasePotionData(new org.bukkit.potion.PotionData(base.getType(), false, base.isExtended()));
            item.setItemMeta(meta);
        }
    }

    private void capEnchant(ItemStack item, Enchantment enchantment, int cap) {
        if (item == null || enchantment == null) return;
        int current = item.getEnchantmentLevel(enchantment);
        if (current > cap) {
            item.removeEnchantment(enchantment);
            item.addUnsafeEnchantment(enchantment, cap);
        }
        if (item.hasItemMeta() && item.getItemMeta() instanceof org.bukkit.inventory.meta.EnchantmentStorageMeta storageMeta) {
            int stored = storageMeta.getStoredEnchantLevel(enchantment);
            if (stored > cap) {
                storageMeta.removeStoredEnchant(enchantment);
                storageMeta.addStoredEnchant(enchantment, cap, true);
                item.setItemMeta(storageMeta);
            }
        }
    }


    private static final class InventorySnapshot {
        private final ItemStack[] contents;
        private final ItemStack[] armor;
        private final ItemStack offhand;
        private final Location location;
        private final double health;
        private final int food;
        private final float saturation;
        private final float exhaustion;
        private final int level;
        private final float exp;
        private final int totalExp;
        private final Collection<PotionEffect> effects;
        private final int heldSlot;

        private InventorySnapshot(Player player) {
            this.contents = cloneItems(player.getInventory().getContents());
            this.armor = cloneItems(player.getInventory().getArmorContents());
            this.offhand = player.getInventory().getItemInOffHand() == null ? null : player.getInventory().getItemInOffHand().clone();
            this.location = player.getLocation().clone();
            this.health = player.getHealth();
            this.food = player.getFoodLevel();
            this.saturation = player.getSaturation();
            this.exhaustion = player.getExhaustion();
            this.level = player.getLevel();
            this.exp = player.getExp();
            this.totalExp = player.getTotalExperience();
            this.effects = new ArrayList<>(player.getActivePotionEffects());
            this.heldSlot = player.getInventory().getHeldItemSlot();
        }

        private static ItemStack[] cloneItems(ItemStack[] items) {
            if (items == null) return new ItemStack[0];
            ItemStack[] out = new ItemStack[items.length];
            for (int i = 0; i < items.length; i++) {
                out[i] = items[i] == null ? null : items[i].clone();
            }
            return out;
        }

        private void restore(Player player) {
            player.getInventory().setContents(cloneItems(contents));
            player.getInventory().setArmorContents(cloneItems(armor));
            player.getInventory().setItemInOffHand(offhand == null ? null : offhand.clone());
            player.getInventory().setHeldItemSlot(Math.max(0, Math.min(8, heldSlot)));
            for (PotionEffect effect : player.getActivePotionEffects()) {
                player.removePotionEffect(effect.getType());
            }
            for (PotionEffect effect : effects) {
                player.addPotionEffect(effect, true);
            }
            player.setHealth(Math.max(1.0, Math.min(player.getAttribute(Attribute.MAX_HEALTH) != null ? player.getAttribute(Attribute.MAX_HEALTH).getValue() : 20.0, health)));
            player.setFoodLevel(food);
            player.setSaturation(saturation);
            player.setExhaustion(exhaustion);
            player.setLevel(level);
            player.setExp(exp);
            player.setTotalExperience(totalExp);
            player.teleport(location);
            player.updateInventory();
        }
    }

    private static final class TestSession {
        private final UUID p1;
        private final UUID p2;
        private int score1;
        private int score2;
        private final Location spawn1;
        private final Location spawn2;
        private final Set<Location> placedBlocks = new HashSet<>();
        private boolean ending;

        private TestSession(UUID p1, UUID p2, Location spawn1, Location spawn2) {
            this.p1 = p1;
            this.p2 = p2;
            this.spawn1 = spawn1;
            this.spawn2 = spawn2;
        }

        private boolean involves(UUID uuid) {
            return p1.equals(uuid) || p2.equals(uuid);
        }

        private UUID opponent(UUID uuid) {
            return p1.equals(uuid) ? p2 : p1;
        }

        private Location spawnFor(UUID uuid) {
            return p1.equals(uuid) ? spawn1 : spawn2;
        }

        private void addPoint(UUID winner) {
            if (p1.equals(winner)) score1++;
            if (p2.equals(winner)) score2++;
        }

        private int score(UUID uuid) {
            return p1.equals(uuid) ? score1 : score2;
        }

        private boolean isFinished() {
            return score1 >= 3 || score2 >= 3;
        }

        private UUID winner() {
            return score1 >= 3 ? p1 : (score2 >= 3 ? p2 : null);
        }
    }

    private Location getTestArenaSpawn(String key) {
        String path = "test.arena." + key;
        String worldName = getConfig().getString(path + ".world");
        if (worldName == null) return null;
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(
                world,
                getConfig().getDouble(path + ".x"),
                getConfig().getDouble(path + ".y"),
                getConfig().getDouble(path + ".z"),
                (float) getConfig().getDouble(path + ".yaw"),
                (float) getConfig().getDouble(path + ".pitch")
        );
    }

    private void setTestArenaSpawn(String key, Location location) {
        String path = "test.arena." + key;
        getConfig().set(path + ".world", location.getWorld() != null ? location.getWorld().getName() : "world");
        getConfig().set(path + ".x", location.getX());
        getConfig().set(path + ".y", location.getY());
        getConfig().set(path + ".z", location.getZ());
        getConfig().set(path + ".yaw", location.getYaw());
        getConfig().set(path + ".pitch", location.getPitch());
        saveConfig();
    }

    private int getTestMaceSlot() {
        return getConfig().getInt("test.kit.mace-slot", -1);
    }

    @SuppressWarnings("unchecked")
    private ItemStack[] getSavedTestKitContents() {
        List<?> raw = getConfig().getList("test.kit.contents");
        if (raw == null) return null;
        ItemStack[] out = new ItemStack[36];
        for (int i = 0; i < Math.min(36, raw.size()); i++) {
            Object value = raw.get(i);
            out[i] = value instanceof ItemStack stack ? stack.clone() : null;
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    private ItemStack[] getSavedTestKitArmor() {
        List<?> raw = getConfig().getList("test.kit.armor");
        if (raw == null) return new ItemStack[4];
        ItemStack[] out = new ItemStack[4];
        for (int i = 0; i < Math.min(4, raw.size()); i++) {
            Object value = raw.get(i);
            out[i] = value instanceof ItemStack stack ? stack.clone() : null;
        }
        return out;
    }

    private ItemStack getSavedTestKitOffhand() {
        Object raw = getConfig().get("test.kit.offhand");
        return raw instanceof ItemStack stack ? stack.clone() : null;
    }

    private boolean hasSavedTestKit() {
        return getSavedTestKitContents() != null && getTestMaceSlot() >= 0;
    }

    private void saveCurrentInventoryAsTestKit(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        int emptySlot = -1;
        for (int i = 0; i < 36; i++) {
            if (contents[i] == null || contents[i].getType() == Material.AIR) {
                emptySlot = i;
                break;
            }
        }
        if (emptySlot < 0) {
            player.sendMessage(ChatColor.RED + "Leave one empty inventory slot for the custom mace, then try again.");
            return;
        }
        List<ItemStack> savedContents = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            savedContents.add(contents[i] == null ? null : contents[i].clone());
        }
        List<ItemStack> savedArmor = new ArrayList<>();
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            savedArmor.add(armor == null ? null : armor.clone());
        }
        getConfig().set("test.kit.contents", savedContents);
        getConfig().set("test.kit.armor", savedArmor);
        getConfig().set("test.kit.offhand", player.getInventory().getItemInOffHand() == null ? null : player.getInventory().getItemInOffHand().clone());
        getConfig().set("test.kit.mace-slot", emptySlot);
        saveConfig();
        player.sendMessage(ChatColor.GREEN + "Test kit saved. Reserved mace slot: " + emptySlot + ".");
    }

    private void clearSavedTestKit(CommandSender sender) {
        getConfig().set("test.kit.contents", null);
        getConfig().set("test.kit.armor", null);
        getConfig().set("test.kit.offhand", null);
        getConfig().set("test.kit.mace-slot", null);
        saveConfig();
        sender.sendMessage(ChatColor.GREEN + "Test kit cleared.");
    }

    private void applyTestLoadout(Player player) {
        ItemStack[] contents = getSavedTestKitContents();
        if (contents == null) return;
        ItemStack[] armor = getSavedTestKitArmor();
        ItemStack offhand = getSavedTestKitOffhand();
        int maceSlot = getTestMaceSlot();

        player.getInventory().clear();
        player.getInventory().setArmorContents(armor);
        player.getInventory().setItemInOffHand(offhand);
        for (int i = 0; i < Math.min(36, contents.length); i++) {
            if (i == maceSlot) continue;
            player.getInventory().setItem(i, contents[i] == null ? null : contents[i].clone());
        }

        String assigned = getAssignedMaceId(player.getUniqueId());
        if (assigned == null) {
            assigned = randomMaceId();
            setAssignedMaceId(player.getUniqueId(), assigned);
        }
        player.getInventory().setItem(maceSlot, createMaceFromId(assigned, player));

        player.setHealth(Math.min(20.0, player.getAttribute(Attribute.MAX_HEALTH) != null ? player.getAttribute(Attribute.MAX_HEALTH).getValue() : 20.0));
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.setExhaustion(0f);
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
        player.setFireTicks(0);
        player.setFallDistance(0f);
        sanitizeInventory(player);
        refreshPassiveEffects(player);
        refreshMaceLore(player);
        refreshPlayerMaceModelStates(player);
        player.updateInventory();
    }

    private void clearTestPlacedBlocks(TestSession session) {
        for (Location loc : new HashSet<>(session.placedBlocks)) {
            if (loc.getWorld() != null) {
                loc.getBlock().setType(Material.AIR, false);
            }
        }
        session.placedBlocks.clear();
    }

    private void startTestMatch(Player initiator, Player target) {
        if (activeTests.containsKey(initiator.getUniqueId()) || activeTests.containsKey(target.getUniqueId())) {
            initiator.sendMessage(ChatColor.RED + "One of those players is already in a test.");
            return;
        }
        if (!hasSavedTestKit()) {
            initiator.sendMessage(ChatColor.RED + "No test kit saved. Use /core testkit save with one empty slot reserved for the mace.");
            return;
        }
        Location spawn1 = getTestArenaSpawn("spawn1");
        Location spawn2 = getTestArenaSpawn("spawn2");
        if (spawn1 == null || spawn2 == null) {
            initiator.sendMessage(ChatColor.RED + "Set arena spawns first with /core testarena setspawn1 and /core testarena setspawn2.");
            return;
        }

        testSnapshots.put(initiator.getUniqueId(), new InventorySnapshot(initiator));
        testSnapshots.put(target.getUniqueId(), new InventorySnapshot(target));

        TestSession session = new TestSession(initiator.getUniqueId(), target.getUniqueId(), spawn1, spawn2);
        activeTests.put(initiator.getUniqueId(), session);
        activeTests.put(target.getUniqueId(), session);

        prepareTestRound(initiator, session.spawn1);
        prepareTestRound(target, session.spawn2);

        initiator.sendTitle(ChatColor.GOLD + "Test Match", ChatColor.YELLOW + "First to 3 rounds", 10, 50, 10);
        target.sendTitle(ChatColor.GOLD + "Test Match", ChatColor.YELLOW + "First to 3 rounds", 10, 50, 10);
        Bukkit.broadcastMessage(ChatColor.LIGHT_PURPLE + initiator.getName() + ChatColor.GRAY + " started a test match against " + ChatColor.LIGHT_PURPLE + target.getName() + ChatColor.GRAY + ".");
    }

    private void prepareTestRound(Player player, Location spawn) {
        if (player == null || !player.isOnline()) return;
        player.teleport(spawn);
        applyTestLoadout(player);
    }

    private void endTestMatch(TestSession session, UUID winnerUuid) {
        if (session == null || session.ending) return;
        session.ending = true;
        clearTestPlacedBlocks(session);

        Player p1 = Bukkit.getPlayer(session.p1);
        Player p2 = Bukkit.getPlayer(session.p2);

        if (p1 != null) {
            InventorySnapshot snapshot = testSnapshots.remove(p1.getUniqueId());
            if (snapshot != null) snapshot.restore(p1);
            activeTests.remove(p1.getUniqueId());
        }
        if (p2 != null) {
            InventorySnapshot snapshot = testSnapshots.remove(p2.getUniqueId());
            if (snapshot != null) snapshot.restore(p2);
            activeTests.remove(p2.getUniqueId());
        }

        Player winner = winnerUuid == null ? null : Bukkit.getPlayer(winnerUuid);
        String winnerName = winner != null ? winner.getName() : "No one";
        if (p1 != null) p1.sendMessage(ChatColor.GOLD + "Test match ended. Winner: " + ChatColor.YELLOW + winnerName);
        if (p2 != null) p2.sendMessage(ChatColor.GOLD + "Test match ended. Winner: " + ChatColor.YELLOW + winnerName);
    }

    private void handleTestRoundDeath(Player victim) {
        TestSession session = activeTests.get(victim.getUniqueId());
        if (session == null || session.ending) return;

        UUID winnerUuid = session.opponent(victim.getUniqueId());
        session.addPoint(winnerUuid);
        clearTestPlacedBlocks(session);

        Player winner = Bukkit.getPlayer(winnerUuid);
        Player loser = victim;

        if (winner != null) {
            winner.sendMessage(ChatColor.GREEN + "Round won. Score: " + session.score(winnerUuid) + " / 3");
        }
        loser.sendMessage(ChatColor.RED + "Round lost.");

        if (session.isFinished()) {
            Bukkit.getScheduler().runTaskLater(this, () -> endTestMatch(session, session.winner()), 40L);
            return;
        }

        pendingTestRoundReset.add(victim.getUniqueId());
        pendingTestRoundReset.add(winnerUuid);

        Bukkit.getScheduler().runTaskLater(this, () -> {
            Player p1 = Bukkit.getPlayer(session.p1);
            Player p2 = Bukkit.getPlayer(session.p2);
            if (p1 != null && p1.isOnline() && !p1.isDead()) {
                prepareTestRound(p1, session.spawn1);
                pendingTestRoundReset.remove(p1.getUniqueId());
            }
            if (p2 != null && p2.isOnline() && !p2.isDead()) {
                prepareTestRound(p2, session.spawn2);
                pendingTestRoundReset.remove(p2.getUniqueId());
            }
        }, 60L);
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "Core commands:");
        sender.sendMessage(ChatColor.YELLOW + "/core help" + ChatColor.GRAY + " - show this command list");
        sender.sendMessage(ChatColor.YELLOW + "/core start" + ChatColor.GRAY + " - start phase 1 and assign maces");
        sender.sendMessage(ChatColor.YELLOW + "/core stop" + ChatColor.GRAY + " - stop the game and remove all core items");
        sender.sendMessage(ChatColor.YELLOW + "/core reroll" + ChatColor.GRAY + " - reroll every player's mace");
        sender.sendMessage(ChatColor.YELLOW + "/core reset" + ChatColor.GRAY + " - reset game, maces, and energy to default");
        sender.sendMessage(ChatColor.YELLOW + "/core give <player> <fire|wind|zeus|jester|wrath|luck|warden|void|vision|dune|random> [amount]" + ChatColor.GRAY + " - give mace(s)");
        sender.sendMessage(ChatColor.YELLOW + "/core giveitem <player> <trader|revivebeacon|repairkit|energybottle> [amount]" + ChatColor.GRAY + " - give special item(s)");
        sender.sendMessage(ChatColor.YELLOW + "/core cooldown set <fire|fireaura|wind|zeuslightning|zeuslock> <seconds>" + ChatColor.GRAY + " - change cooldown");
        sender.sendMessage(ChatColor.YELLOW + "/core cooldown get [ability]" + ChatColor.GRAY + " - show cooldown(s)");
        sender.sendMessage(ChatColor.YELLOW + "/core energy get [player]" + ChatColor.GRAY + " - show energy");
        sender.sendMessage(ChatColor.YELLOW + "/core energy set <player> <0-5>" + ChatColor.GRAY + " - set energy");
        sender.sendMessage(ChatColor.YELLOW + "/core revive" + ChatColor.GRAY + " - open the Revive Beacon menu");
        sender.sendMessage(ChatColor.YELLOW + "/core recipes" + ChatColor.GRAY + " - open the custom recipe GUI");
        sender.sendMessage(ChatColor.YELLOW + "/core test <player>" + ChatColor.GRAY + " - start a first-to-3 arena test match");
        sender.sendMessage(ChatColor.YELLOW + "/core testkit save" + ChatColor.GRAY + " - import the current inventory as the test kit (leave one empty slot for the mace)");
        sender.sendMessage(ChatColor.YELLOW + "/core testkit clear" + ChatColor.GRAY + " - clear the saved test kit");
        sender.sendMessage(ChatColor.YELLOW + "/core testarena setspawn1|setspawn2" + ChatColor.GRAY + " - save arena spawn points");
        sender.sendMessage(ChatColor.YELLOW + "/core reload" + ChatColor.GRAY + " - reload config");
    }

    private String cooldownPath(String ability) {
        return switch (ability.toLowerCase(Locale.ROOT)) {
            case "fire" -> "cooldowns.fire-seconds";
            case "fireaura", "aura", "inferno" -> "cooldowns.fire-aura-seconds";
            case "wind" -> "cooldowns.wind-seconds";
            case "zeuslightning", "lightning", "zeus-lightning" -> "cooldowns.zeus-lightning-seconds";
            case "zeuslock", "lock", "zeus-lock" -> "cooldowns.zeus-lock-seconds";
            case "wrath", "bloodhunt", "wrathbloodhunt" -> "cooldowns.wrath-bloodhunt-seconds";
            case "luck", "cointoss", "coin" -> "cooldowns.luck-coin-seconds";
            default -> null;
        };
    }

    private String cooldownDisplayName(String path) {
        return switch (path) {
            case "cooldowns.fire-seconds" -> "fire";
            case "cooldowns.fire-aura-seconds" -> "fireaura";
            case "cooldowns.wind-seconds" -> "wind";
            case "cooldowns.zeus-lightning-seconds" -> "zeuslightning";
            case "cooldowns.zeus-lock-seconds" -> "zeuslock";
            case "cooldowns.wrath-bloodhunt-seconds" -> "wrath";
            case "cooldowns.luck-coin-seconds" -> "luck";
            default -> path;
        };
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("core.command")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendUsage(sender);
            return true;
        }

        if (args[0].equalsIgnoreCase("start")) {
            startServerPhaseOne(sender);
            return true;
        }

        if (args[0].equalsIgnoreCase("stop")) {
            stopCoreGame(sender, false);
            return true;
        }

        if (args[0].equalsIgnoreCase("reroll")) {
            if (!hasStarted()) {
                sender.sendMessage(ChatColor.RED + "The game has not started yet.");
                return true;
            }
            Bukkit.broadcastMessage(ChatColor.GOLD + "Fate has been rewritten. The divine maces shift once more...");
            for (Player online : Bukkit.getOnlinePlayers()) {
                storePlayerName(online);
                removeAllCustomMaces(online);
                setAssignedMaceId(online.getUniqueId(), randomMaceId());
                giveAssignedMaceInstant(online);
                online.playSound(online.getLocation(), Sound.ITEM_TRIDENT_THUNDER, 0.8f, 1.2f);
                online.sendMessage(ChatColor.LIGHT_PURPLE + "The gods have rerolled your mace.");
            }
            sender.sendMessage(ChatColor.GREEN + "Rerolled all online players' maces.");
            return true;
        }

        if (args[0].equalsIgnoreCase("reset")) {
            stopCoreGame(sender, true);
            return true;
        }

        if (args[0].equalsIgnoreCase("test")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Only players can use /core test.");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /core test <player>");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null || !target.isOnline()) {
                sender.sendMessage(ChatColor.RED + "That player is not online.");
                return true;
            }
            if (target.getUniqueId().equals(player.getUniqueId())) {
                sender.sendMessage(ChatColor.RED + "Pick another player.");
                return true;
            }
            startTestMatch(player, target);
            return true;
        }

        if (args[0].equalsIgnoreCase("testkit")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Only players can manage the test kit.");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /core testkit <save|clear>");
                return true;
            }
            if (args[1].equalsIgnoreCase("save")) {
                saveCurrentInventoryAsTestKit(player);
                return true;
            }
            if (args[1].equalsIgnoreCase("clear")) {
                clearSavedTestKit(player);
                return true;
            }
            sender.sendMessage(ChatColor.RED + "Usage: /core testkit <save|clear>");
            return true;
        }

        if (args[0].equalsIgnoreCase("testarena")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Only players can set arena spawns.");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(ChatColor.RED + "Usage: /core testarena <setspawn1|setspawn2>");
                return true;
            }
            if (args[1].equalsIgnoreCase("setspawn1")) {
                setTestArenaSpawn("spawn1", player.getLocation());
                sender.sendMessage(ChatColor.GREEN + "Test arena spawn 1 saved.");
                return true;
            }
            if (args[1].equalsIgnoreCase("setspawn2")) {
                setTestArenaSpawn("spawn2", player.getLocation());
                sender.sendMessage(ChatColor.GREEN + "Test arena spawn 2 saved.");
                return true;
            }
            sender.sendMessage(ChatColor.RED + "Usage: /core testarena <setspawn1|setspawn2>");
            return true;
        }


        if (args[0].equalsIgnoreCase("give")) {
            if (args.length < 3) {
                sendUsage(sender);
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Player not found: " + args[1]);
                return true;
            }
            ItemStack baseMace = createMaceByName(args[2], target);
            if (baseMace == null) {
                sender.sendMessage(ChatColor.RED + "Unknown mace. Use fire, wind, zeus, jester, wrath, luck, warden, void, vision, dune, or random.");
                return true;
            }
            int amount = parseAmount(sender, args, 3);
            if (amount < 1) return true;
            for (int i = 0; i < amount; i++) {
                ItemStack mace = args[2].equalsIgnoreCase("random") ? createMaceByName("random", target) : baseMace.clone();
                target.getInventory().addItem(mace);
            }
            sender.sendMessage(ChatColor.GREEN + "Gave " + amount + " " + args[2].toLowerCase(Locale.ROOT) + " mace(s) to " + target.getName() + ".");
            return true;
        }

        if (args[0].equalsIgnoreCase("giveitem")) {
            if (args.length < 3) {
                sendUsage(sender);
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Player not found: " + args[1]);
                return true;
            }
            ItemStack base = createSpecialByName(args[2]);
            if (base == null) {
                sender.sendMessage(ChatColor.RED + "Unknown item. Use trader, revivebeacon, repairkit, or energybottle.");
                return true;
            }
            int amount = parseAmount(sender, args, 3);
            if (amount < 1) return true;
            ItemStack stack = base.clone();
            stack.setAmount(Math.min(amount, stack.getMaxStackSize()));
            int left = amount;
            while (left > 0) {
                ItemStack give = base.clone();
                give.setAmount(Math.min(left, give.getMaxStackSize()));
                target.getInventory().addItem(give);
                left -= give.getAmount();
            }
            sender.sendMessage(ChatColor.GREEN + "Gave " + amount + " " + args[2].toLowerCase(Locale.ROOT) + " to " + target.getName() + ".");
            return true;
        }

        if (args[0].equalsIgnoreCase("cooldown")) {
            if (args.length >= 2 && args[1].equalsIgnoreCase("get")) {
                if (args.length == 2) {
                    sender.sendMessage(ChatColor.GOLD + "Current cooldowns:");
                    for (String path : List.of("cooldowns.fire-seconds", "cooldowns.wind-seconds", "cooldowns.zeus-lightning-seconds", "cooldowns.zeus-lock-seconds", "cooldowns.wrath-bloodhunt-seconds", "cooldowns.luck-coin-seconds")) {
                        sender.sendMessage(ChatColor.YELLOW + cooldownDisplayName(path) + ChatColor.GRAY + ": " + getConfig().getDouble(path) + "s");
                    }
                    return true;
                }
                String path = cooldownPath(args[2]);
                if (path == null) {
                    sender.sendMessage(ChatColor.RED + "Unknown ability. Use fire, wind, zeuslightning, or zeuslock.");
                    return true;
                }
                sender.sendMessage(ChatColor.YELLOW + cooldownDisplayName(path) + ChatColor.GRAY + ": " + getConfig().getDouble(path) + "s");
                return true;
            }
            if (args.length == 4 && args[1].equalsIgnoreCase("set")) {
                String path = cooldownPath(args[2]);
                if (path == null) {
                    sender.sendMessage(ChatColor.RED + "Unknown ability. Use fire, wind, zeuslightning, or zeuslock.");
                    return true;
                }
                double seconds;
                try {
                    seconds = Double.parseDouble(args[3]);
                } catch (NumberFormatException e) {
                    sender.sendMessage(ChatColor.RED + "Seconds must be a number.");
                    return true;
                }
                if (seconds < 0) {
                    sender.sendMessage(ChatColor.RED + "Seconds cannot be negative.");
                    return true;
                }
                getConfig().set(path, seconds);
                saveConfig();
                sender.sendMessage(ChatColor.GREEN + "Set " + cooldownDisplayName(path) + " cooldown to " + seconds + "s.");
                return true;
            }
            sendUsage(sender);
            return true;
        }


        if (args[0].equalsIgnoreCase("withdraw")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Only players can withdraw energy.");
                return true;
            }
            int amount = 1;
            if (args.length >= 2) {
                try {
                    amount = Integer.parseInt(args[1]);
                } catch (NumberFormatException e) {
                    sender.sendMessage(ChatColor.RED + "Usage: /core withdraw <amount>");
                    return true;
                }
            }
            amount = Math.max(1, amount);

            int current = getEnergy(player.getUniqueId());
            if (current <= 0) {
                sender.sendMessage(ChatColor.RED + "You have no energy to withdraw.");
                return true;
            }
            if (amount > current) {
                sender.sendMessage(ChatColor.RED + "You only have " + current + " energy available.");
                return true;
            }

            setEnergy(player.getUniqueId(), player.getName(), current - amount);

            int remaining = amount;
            while (remaining > 0) {
                ItemStack bottle = createEnergyBottle();
                int stackAmount = Math.min(remaining, bottle.getMaxStackSize());
                bottle.setAmount(stackAmount);
                player.getInventory().addItem(bottle);
                remaining -= stackAmount;
            }

            refreshMaceLore(player);
            refreshPassiveEffects(player);
            sender.sendMessage(ChatColor.GREEN + "You bottled " + amount + " energy.");
            return true;
        }

        if (args[0].equalsIgnoreCase("energy")) {
            if (args.length >= 2 && args[1].equalsIgnoreCase("get")) {
                if (args.length == 2) {
                    if (!(sender instanceof Player player)) {
                        sender.sendMessage(ChatColor.RED + "Console must specify a player.");
                        return true;
                    }
                    sender.sendMessage(ChatColor.YELLOW + player.getName() + ChatColor.GRAY + " energy: " + getEnergy(player.getUniqueId()) + "/" + getMaxEnergy());
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[2]);
                sender.sendMessage(ChatColor.YELLOW + target.getName() + ChatColor.GRAY + " energy: " + getEnergy(target.getUniqueId()) + "/" + getMaxEnergy());
                return true;
            }
            if (args.length == 4 && args[1].equalsIgnoreCase("set")) {
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[2]);
                int value;
                try {
                    value = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    sender.sendMessage(ChatColor.RED + "Energy must be a number.");
                    return true;
                }
                value = Math.max(0, Math.min(getMaxEnergy(), value));
                setEnergy(target.getUniqueId(), target.getName() == null ? args[2] : target.getName(), value);
                sender.sendMessage(ChatColor.GREEN + "Set " + (target.getName() == null ? args[2] : target.getName()) + " energy to " + value + "/" + getMaxEnergy() + ".");
                return true;
            }
            sendUsage(sender);
            return true;
        }

        if (args[0].equalsIgnoreCase("revive")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Only players can open the Revive Beacon menu.");
                return true;
            }
            if (args.length != 1) {
                sendUsage(sender);
                return true;
            }
            openReviveMenu(player);
            return true;
        }

        if (args[0].equalsIgnoreCase("recipes")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Only players can open the recipe menu.");
                return true;
            }
            openRecipeMenu(player);
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            applyDefaultConfigValues();
            sender.sendMessage(ChatColor.GREEN + "Core config reloaded.");
            return true;
        }

        sendUsage(sender);
        return true;
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        java.util.List<String> out = new java.util.ArrayList<>();
        if (!sender.hasPermission("core.command")) return out;

        if (args.length == 1) {
            return partial(args[0], java.util.List.of("help", "start", "stop", "reroll", "reset", "give", "giveitem", "cooldown", "energy", "revive", "recipes", "withdraw", "reload", "test", "testkit", "testarena"));
        }
        if (args.length == 2) {
            return switch (args[0].toLowerCase(java.util.Locale.ROOT)) {
                case "give", "giveitem" -> partialPlayers(args[1]);
                case "cooldown" -> partial(args[1], java.util.List.of("get", "set"));
                case "energy" -> partial(args[1], java.util.List.of("get", "set"));
                case "withdraw" -> partial(args[1], java.util.List.of("1", "2", "3"));
                case "test" -> partialPlayers(args[1]);
                case "testkit" -> partial(args[1], java.util.List.of("save", "clear"));
                case "testarena" -> partial(args[1], java.util.List.of("setspawn1", "setspawn2"));
                default -> out;
            };
        }
        if (args.length == 3) {
            return switch (args[0].toLowerCase(java.util.Locale.ROOT)) {
                case "give" -> partial(args[2], java.util.List.of("fire", "wind", "zeus", "jester", "wrath", "luck", "warden", "void", "vision", "dune", "random"));
                case "giveitem" -> partial(args[2], java.util.List.of("trader", "revivebeacon", "repairkit", "energybottle"));
                case "cooldown" -> partial(args[2], java.util.List.of("fire", "fireaura", "wind", "zeuslightning", "zeuslock", "wrath", "luck", "warden-slam", "warden-darkness", "void-blink", "void-pull", "vision-blind", "vision-void", "dune-wave", "dune-pit"));
                case "energy" -> ("set".equalsIgnoreCase(args[1]) || "get".equalsIgnoreCase(args[1])) ? partialPlayers(args[2]) : out;
                default -> out;
            };
        }
        if (args.length == 4) {
            if ("cooldown".equalsIgnoreCase(args[0]) && "set".equalsIgnoreCase(args[1])) {
                return java.util.List.of("<seconds>");
            }
            if ("energy".equalsIgnoreCase(args[0]) && "set".equalsIgnoreCase(args[1])) {
                return partial(args[3], java.util.List.of("0", "1", "2", "3", "4", "5"));
            }
            if ("give".equalsIgnoreCase(args[0]) || "giveitem".equalsIgnoreCase(args[0])) {
                return java.util.List.of("<amount>");
            }
        }
        return out;
    }

    private java.util.List<String> partialPlayers(String token) {
        java.util.List<String> names = new java.util.ArrayList<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            names.add(player.getName());
        }
        return partial(token, names);
    }

    private java.util.List<String> partial(String token, java.util.List<String> options) {
        String lower = token.toLowerCase(java.util.Locale.ROOT);
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase(java.util.Locale.ROOT).startsWith(lower)) {
                out.add(option);
            }
        }
        return out;
    }

    private int parseAmount(CommandSender sender, String[] args, int index) {
        if (args.length <= index) return 1;
        try {
            return Math.max(1, Integer.parseInt(args[index]));
        } catch (NumberFormatException e) {
            sender.sendMessage(ChatColor.RED + "Amount must be a number.");
            return -1;
        }
    }

    private int getEnergy(UUID uuid) {
        return getConfig().getInt("players." + uuid + ".energy", getMaxEnergy());
    }

    private void setEnergy(UUID uuid, String name, int value) {
        if (name != null) {
            getConfig().set("players." + uuid + ".name", name);
        }
        getConfig().set("players." + uuid + ".energy", Math.max(0, Math.min(getMaxEnergy(), value)));
        saveConfig();
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) {
            refreshMaceLore(online);
        }
    }

    private void storePlayerName(Player player) {
        if (player == null) return;
        if (!getConfig().contains("players." + player.getUniqueId() + ".energy")) {
            setEnergy(player.getUniqueId(), player.getName(), getMaxEnergy());
        } else {
            getConfig().set("players." + player.getUniqueId() + ".name", player.getName());
            saveConfig();
        }
    }

    private int getMaxEnergy() {
        return getConfig().getInt("energy.max", MAX_ENERGY);
    }

    private boolean isReviveBanned(String name) {
        return getConfig().getBoolean("revive-banned." + name.toLowerCase(Locale.ROOT), false);
    }

    private void markReviveBanned(String name, boolean banned) {
        getConfig().set("revive-banned." + name.toLowerCase(Locale.ROOT), banned ? true : null);
        saveConfig();
    }

    private boolean consumeHeldSpecialItem(Player player, String specialId) {
        ItemStack main = player.getInventory().getItemInMainHand();
        if (!specialId.equals(getSpecialItemId(main))) {
            player.sendMessage(ChatColor.RED + "You must hold that item in your main hand.");
            return false;
        }
        decrementStack(player.getInventory(), player.getInventory().getHeldItemSlot(), main);
        return true;
    }

    private boolean consumeItemAnywhere(Player player, String specialId) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (specialId.equals(getSpecialItemId(item))) {
                decrementStack(player.getInventory(), i, item);
                return true;
            }
        }
        return false;
    }

    private void decrementStack(PlayerInventory inventory, int slot, ItemStack item) {
        if (item.getAmount() <= 1) {
            inventory.setItem(slot, null);
        } else {
            item.setAmount(item.getAmount() - 1);
            inventory.setItem(slot, item);
        }
    }

    private void removeAllCustomMaces(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (getMaceId(contents[i]) != null) {
                player.getInventory().setItem(i, null);
            }
        }
    }

    private ItemStack findRepairableMace(PlayerInventory inventory) {
        ItemStack main = inventory.getItemInMainHand();
        if (getMaceId(main) != null) return main;
        ItemStack off = inventory.getItemInOffHand();
        if (getMaceId(off) != null) return off;
        for (ItemStack item : inventory.getContents()) {
            if (getMaceId(item) != null) return item;
        }
        return null;
    }

    private boolean hasAnyCustomMace(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (getMaceId(item) != null) {
                return true;
            }
        }
        return false;
    }

    private void rememberAssignedMace(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            String id = getMaceId(item);
            if (id != null) {
                setAssignedMaceId(player.getUniqueId(), id);
                return;
            }
        }
        String heldId = getMaceId(player.getInventory().getItemInMainHand());
        if (heldId != null) {
            setAssignedMaceId(player.getUniqueId(), heldId);
        }
    }

    private void setAssignedMaceId(UUID uuid, String maceId) {
        getConfig().set("players." + uuid + ".assigned-mace", maceId);
        saveConfig();
    }

    private String getAssignedMaceId(UUID uuid) {
        return getConfig().getString("players." + uuid + ".assigned-mace");
    }

    private void giveAssignedMaceInstant(Player player) {
        String assigned = getAssignedMaceId(player.getUniqueId());
        if (assigned == null) {
            assigned = randomMaceId();
            setAssignedMaceId(player.getUniqueId(), assigned);
        }
        removeAllCustomMaces(player);
        ItemStack mace = createMaceFromId(assigned, player);

        World world = player.getWorld();
        Location top = player.getLocation().clone().add(0, 7.0, 0);
        player.playSound(player.getLocation(), Sound.ITEM_TRIDENT_THUNDER, 0.8f, 1.2f);

        new BukkitRunnable() {
            int step = 0;
            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                Location current = top.clone().add(0, -0.45 * step, 0);
                world.spawnParticle(Particle.ENCHANT, current, 18, 0.18, 0.25, 0.18, 0.01);
                world.spawnParticle(Particle.ELECTRIC_SPARK, current, 8, 0.12, 0.12, 0.12, 0.0);
                world.spawnParticle(Particle.FLAME, current, 4, 0.08, 0.08, 0.08, 0.0);
                step++;
                if (step >= 14) {
                    player.getInventory().addItem(mace);
                    world.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 0.7f);
                    world.spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 24, 0.35, 0.55, 0.35, 0.02);
                    sanitizeInventory(player);
                    refreshPassiveEffects(player);
                    refreshMaceLore(player);
                    cancel();
                }
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    private void applyHiddenEnchantStyle(ItemMeta meta) {
        if (meta == null) return;
        
    }


    private boolean isZeroEnergyDisabled(Player player) {
        return player != null && getEnergy(player.getUniqueId()) <= 0;
    }



    private void syncMaceDamageVisual(ItemStack item, int energy) {
        if (item == null || !(item.getItemMeta() instanceof Damageable damageable)) return;

        int maxDurability = item.getType().getMaxDurability();
        if (maxDurability <= 0) return;

        int clamped = Math.max(0, Math.min(5, energy));

        double ratioUsed = switch (clamped) {
            case 5 -> 0.0;   // full bar
            case 4 -> 0.18;  // light wear
            case 3 -> 0.42;  // visible wear
            case 2 -> 0.68;  // medium
            case 1 -> 0.92;  // barely alive
            case 0 -> 0.98;  // broken
            default -> 0.0;
        };

        int visualDamage = ratioUsed <= 0.0 ? 0 : Math.min(maxDurability - 1, Math.max(1, (int) Math.round(maxDurability * ratioUsed)));
        damageable.setDamage(visualDamage);
        item.setItemMeta((ItemMeta) damageable);
    }

    private void setMaceModel(ItemStack item, int modelData) {
        if (item == null || !item.hasItemMeta()) return;
        String maceId = getMaceId(item);
        if (maceId == null) return;
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        meta.setCustomModelData(modelData);
        item.setItemMeta(meta);
    }

    private void refreshPlayerMaceModelStates(Player player) {
        if (player == null) return;
        PlayerInventory inv = player.getInventory();
        int heldSlot = inv.getHeldItemSlot();
        int energy = getEnergy(player.getUniqueId());

        for (int slot = 0; slot < inv.getSize(); slot++) {
            ItemStack item = inv.getItem(slot);
            String maceId = getMaceId(item);
            if (maceId == null) continue;

            int model = (slot == heldSlot)
                    ? getMaceModelData(maceId, energy)
                    : getGuiModelData(maceId);
            setMaceModel(item, model);
            syncMaceDamageVisual(item, energy);
        }

        ItemStack offhand = inv.getItemInOffHand();
        String offhandMaceId = getMaceId(offhand);
        if (offhandMaceId != null) {
            setMaceModel(offhand, getMaceModelData(offhandMaceId, energy));
            syncMaceDamageVisual(offhand, energy);
        }
    }

    private int getSpecialItemModelData(String specialId) {
        return switch (specialId) {
            case ITEM_TRADER -> 11001;
            case ITEM_REPAIR -> 11002;
            case ITEM_ENERGY -> 11003;
            default -> 0;
        };
    }

    

    private int getMaceBaseModelData(String maceId) {
        return switch (maceId) {
            case FIRE_ID -> 1000;
            case WIND_ID -> 2000;
            case ZEUS_ID -> 3000;
            case JESTER_ID -> 4000;
            case WRATH_ID -> 5000;
            case LUCK_ID -> 6000;
            case WARDEN_ID -> 7000;
            case VOID_ID -> 8000;
            case VISION_ID -> 9000;
            case DUNE_ID -> 10000;
            default -> 1000;
        };
    }

    private int getGuiModelData(String maceId) {
        return getMaceBaseModelData(maceId);
    }

    private int getMaceModelData(String maceId, int energy) {
        int base = getMaceBaseModelData(maceId);

        return switch (energy) {
            case 6 -> base + 1; // full
            case 5 -> base + 2; // small scratches
            case 4 -> base + 3; // visible scratches
            case 3 -> base + 4; // medium
            case 2 -> base + 5; // barely alive
            case 1, 0 -> base + 6; // broken
            default -> base + 1;
        };
    }

    private void decorateMace(ItemStack item, Player owner) {
        String maceId = getMaceId(item);
        if (maceId == null || !item.hasItemMeta()) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(false);
        
        if (owner != null) {
            meta.setCustomModelData(getMaceModelData(maceId, getEnergy(owner.getUniqueId())));
        }
        List<String> lore = new ArrayList<>();
        switch (maceId) {
            case FIRE_ID -> {
                lore.add(formatAbilityLine("Ability I", "Hurl a blazing fireball that bursts on impact"));
                lore.add(formatAbilityLine("Ability II", "Sneak-right-click to awaken Inferno Aura around you"));
                lore.add(formatPassiveLine("Passive", "Fire resistance while the mace is yours"));
            }
            case WIND_ID -> {
                lore.add(formatAbilityLine("Ability I", "Right-click to cut through the air with a divine dash"));
                lore.add(formatPassiveLine("Passive", "Negate fall damage while the mace is yours"));
            }
            case ZEUS_ID -> {
                lore.add(formatAbilityLine("Ability I", "Call lightning exactly where your aim lands"));
                lore.add(formatAbilityLine("Ability II", "Sneak-right-click to pin a target in place"));
                lore.add(formatPassiveLine("Passive", "A constant burst of speed while owned"));
            }
            case JESTER_ID -> {
                lore.add(formatAbilityLine("Ringmaster", "Every 5 hits may curse your target with a random debuff"));
                lore.add(formatAbilityLine("Copycat", "Every 5 hits may steal a target's mace for 4 strikes"));
                lore.add(formatPassiveLine("Passive", "Chaos grows stronger the longer the fight lasts"));
            }
            case WRATH_ID -> {
                lore.add(formatAbilityLine("Bloodhunt", "Enter a killing state with speed, strength, and marked prey"));
                lore.add(formatPassiveLine("Berserker", "The less health you have, the harder you hit"));
            }
            case LUCK_ID -> {
                lore.add(formatAbilityLine("Coin Toss", "Arm your next hit with a blessing or a backfire"));
                lore.add(formatPassiveLine("Luck Meter", "Bad rolls quietly bend the next toss in your favor"));
                lore.add(formatPassiveLine("Bad Luck Meter", "Too many blessings invite a harsher answer"));
            }
            case WARDEN_ID -> {
                lore.add(formatAbilityLine("Ability I", "Slam the ground and send a brutal sonic shockwave"));
                lore.add(formatAbilityLine("Ability II", "Sneak-right-click to drown nearby enemies in darkness"));
                lore.add(formatPassiveLine("Passive", "Blindness and darkness cannot cling to you"));
            }
            case VOID_ID -> {
                lore.add(formatAbilityLine("Ability I", "Blink forward and crash down with void-touched force"));
                lore.add(formatAbilityLine("Ability II", "Sneak-right-click to drag enemies toward the abyss"));
                lore.add(formatPassiveLine("Passive", "Reduced fall damage and withering strikes"));
            }
            case VISION_ID -> {
                lore.add(formatAbilityLine("Ability I", "Blind an enemy and slow their escape"));
                lore.add(formatAbilityLine("Ability II", "Erase a target's world into black silence for 3 seconds"));
                lore.add(formatPassiveLine("Passive", "Control space, sight, and tempo"));
            }
            case DUNE_ID -> {
                lore.add(formatAbilityLine("Ability I", "Send a long sand wave rolling through your enemies"));
                lore.add(formatAbilityLine("Ability II", "Summon quicksand that anchors victims in place"));
                lore.add(formatPassiveLine("Passive", "Gain speed while crossing sand"));
            }
        }

        if (owner != null) {
            int energy = getEnergy(owner.getUniqueId());
            lore.add("");
            lore.add(formatEnergyLine(energy));
            if (energy <= 0) {
                lore.add(ChatColor.RED + "✦ Dormant — no mace damage, passives, or active abilities");
            }
        }

        meta.setLore(lore);
        item.setItemMeta(meta);
    }

    private void refreshMaceLore(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (getMaceId(item) != null) {
                decorateMace(item, player);
            }
        }
        ItemStack off = player.getInventory().getItemInOffHand();
        if (getMaceId(off) != null) {
            decorateMace(off, player);
        }
        refreshPlayerMaceModelStates(player);
    }

    private String energyStateName(int energy) {
        return switch (Math.max(0, Math.min(getMaxEnergy(), energy))) {
            case 5 -> "Unscarred";
            case 4 -> "Scratched";
            case 3 -> "Cracked";
            case 2 -> "Fractured";
            case 1 -> "Shattered";
            default -> "Depleted";
        };
    }

}
