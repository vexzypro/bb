# Core

A Paper 1.21.x Minecraft plugin inspired by the idea of class-based SMP powers, but using **random spawn maces** instead of gems/upgraders.

## What it does

When a player joins or respawns:
- a particle circle appears around them
- one random mace is chosen
- the player receives **Fire Mace**, **Wind Mace**, or **Zeus Mace**

## Maces

### Fire Mace
- Right click: shoots a giant magma block projectile
- Passive: fire resistance while holding it
- Built-in enchant: Fire Aspect II

### Wind Mace
- Right click: launches you into the air
- Passive: fall damage is cancelled while holding it
- Built-in enchant: Wind Burst II

### Zeus Mace
- Right click: lightning strike at your looked-at target/location
- Shift + right click: locks a target in place for 3 seconds
  - no movement
  - no jump
  - no knockback

## Command
- `/core random`
- `/core fire`
- `/core wind`
- `/core zeus`

## Build
Use Maven:

```bash
mvn package
```

The built jar will be placed in `target/`.

## Server target
This project is set up for **Paper 1.21.11** and Java 21.

## Notes
This is a clean starter implementation, so you may still want to tune:
- damage values
- cooldowns
- particle density
- whether players should get a new mace every respawn only, or also on first join only
- PvP balance for the Zeus lock


New in v1.3.4:
- /core start begins phase 1 and assigns random maces
- no maces before the start command
- phase 1 caps enchants to Prot 3 / Sharp 4 / Density 4 / Breach 3
- ender pearls never teleport players
- Ender Dragon death starts phase 2 and removes enchant caps
- players cannot drop their mace


## New
- `/core recipes` opens a GUI showing the Repair Kit, Mace Trader, and Revive Beacon recipes.
